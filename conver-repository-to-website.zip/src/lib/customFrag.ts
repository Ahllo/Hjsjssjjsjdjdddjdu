/**
 * Ejecuta fragment shaders de Psych Engine / P-Slice en la vista previa con WebGL.
 *
 * Los .frag de FNF usan el convenio de OpenFL: empiezan por `#pragma header`, leen la
 * imagen de la capa con `flixel_texture2D(bitmap, openfl_TextureCoordv)` y escriben en
 * `gl_FragColor`. Aquí se expande ese `#pragma header` en el preámbulo real (samplers,
 * varyings y uniforms) y se pinta la capa como un quad a pantalla completa.
 *
 * Optimización para que vaya fino en la web:
 *  - UN solo contexto WebGL compartido entre todas las capas con shader.
 *  - Los programas se compilan una vez por código y se cachean (no se recompilan por frame).
 *  - Se renderiza con el lado mayor limitado a 512 px y se escala al componer: los shaders
 *    trabajan en UV (0..1), así que el efecto es el mismo y cuesta una fracción.
 *  - Si un shader no compila se marca como roto y no se reintenta (avita picos por frame).
 */

const MAX_SIDE = 512;

const VERT =
  'attribute vec2 aPos;attribute vec2 aTex;varying vec2 openfl_TextureCoordv;' +
  'void main(){gl_Position=vec4(aPos,0.0,1.0);openfl_TextureCoordv=aTex;}';

let glCanvas: HTMLCanvasElement | null = null;
let gl: WebGLRenderingContext | null = null;
let stageCanvas: HTMLCanvasElement | null = null;
let stageCtx: CanvasRenderingContext2D | null = null;
let quadBuf: WebGLBuffer | null = null;
let texBuf: WebGLBuffer | null = null;
/** texturas ya subidas a la GPU por contenido: un sprite fijo con un shader animado por uTime
 *  sube la textura UNA vez y después solo re-renderiza (esto es lo que quitaba el lag) */
const texPool = new Map<string, WebGLTexture>();

interface ProgEntry {
  prog: WebGLProgram;
  uBitmap: WebGLUniformLocation | null;
  uSize: WebGLUniformLocation | null;
  uTime: WebGLUniformLocation | null;
  aPos: number;
  aTex: number;
}
const progs = new Map<string, ProgEntry>();
const broken = new Map<string, string>(); // clave -> error de compilación

function hashFrag(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
}

/** En qué se convierte el `#pragma header` de los shaders de FNF */
function fragPreamble(): string {
  return [
    '#ifdef GL_ES',
    'precision mediump float;',
    '#endif',
    'varying vec2 openfl_TextureCoordv;',
    'uniform sampler2D bitmap;',
    'uniform vec2 openfl_TextureSize;',
    'uniform float uTime;',
    'uniform float elapsed;',
    'vec4 flixel_texture2D(sampler2D tex, vec2 uv){return texture2D(tex, uv);}',
    '',
  ].join('\n');
}

function expandFrag(src: string): string {
  return /^\s*#pragma\s+header/m.test(src) ? src.replace(/^\s*#pragma\s+header[^\n]*$/m, fragPreamble()) : fragPreamble() + '\n' + src;
}

function getGL(): WebGLRenderingContext | null {
  if (gl) return gl;
  glCanvas = document.createElement('canvas');
  gl = glCanvas.getContext('webgl', { premultipliedAlpha: false, antialias: false, depth: false, stencil: false, alpha: true }) as WebGLRenderingContext | null;
  if (!gl) return null;
  quadBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, quadBuf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  texBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, texBuf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 1, 1, 1, 0, 0, 1, 0]), gl.STATIC_DRAW);
  return gl;
}

function compile(g: WebGLRenderingContext, fragSrc: string): { prog: WebGLProgram } | { error: string } {
  const vs = g.createShader(g.VERTEX_SHADER)!;
  g.shaderSource(vs, VERT);
  g.compileShader(vs);
  if (!g.getShaderParameter(vs, g.COMPILE_STATUS)) return { error: 'vertex: ' + g.getShaderInfoLog(vs) };
  const fs = g.createShader(g.FRAGMENT_SHADER)!;
  g.shaderSource(fs, fragSrc);
  g.compileShader(fs);
  if (!g.getShaderParameter(fs, g.COMPILE_STATUS)) return { error: String(g.getShaderInfoLog(fs) || 'error de compilación') };
  const prog = g.createProgram()!;
  g.attachShader(prog, vs);
  g.attachShader(prog, fs);
  g.linkProgram(prog);
  if (!g.getProgramParameter(prog, g.LINK_STATUS)) return { error: String(g.getProgramInfoLog(prog) || 'error de enlace') };
  return { prog };
}

/**
 * Comprueba si un .frag compila, sin tocar el estado de la vista previa.
 * Devuelve null si está bien o el mensaje de error para enseñárselo a la persona.
 */
export function checkFrag(code: string): string | null {
  if (!code.trim()) return null;
  const g = getGL();
  if (!g) return null;
  const key = code.length + ':' + hashFrag(code);
  if (broken.has(key)) return broken.get(key)!;
  if (progs.has(key)) return null;
  const r = compile(g, expandFrag(code));
  if ('error' in r) {
    broken.set(key, r.error);
    return r.error;
  }
  progs.set(key, {
    prog: r.prog,
    uBitmap: g.getUniformLocation(r.prog, 'bitmap'),
    uSize: g.getUniformLocation(r.prog, 'openfl_TextureSize'),
    uTime: g.getUniformLocation(r.prog, 'uTime'),
    aPos: g.getAttribLocation(r.prog, 'aPos'),
    aTex: g.getAttribLocation(r.prog, 'aTex'),
  });
  return null;
}

/**
 * Pinta la región (sx,sy,fw,fh) de `src` pasada por el fragment shader `code`.
 * Devuelve el canvas WebGL compartido (hay que dibujarlo en el 2D antes de la siguiente llamada).
 */
export function runFragShader(
  code: string,
  src: CanvasImageSource,
  sx: number,
  sy: number,
  fw: number,
  fh: number,
  time: number,
  sig?: string,
): HTMLCanvasElement | null {
  const g = getGL();
  if (!g || !glCanvas || fw < 1 || fh < 1) return null;
  const key = code.length + ':' + hashFrag(code);
  if (broken.has(key)) return null;

  let entry = progs.get(key);
  if (!entry) {
    const r = compile(g, expandFrag(code));
    if ('error' in r) {
      broken.set(key, r.error);
      if (broken.size > 100) broken.clear();
      return null;
    }
    entry = {
      prog: r.prog,
      uBitmap: g.getUniformLocation(r.prog, 'bitmap'),
      uSize: g.getUniformLocation(r.prog, 'openfl_TextureSize'),
      uTime: g.getUniformLocation(r.prog, 'uTime'),
      aPos: g.getAttribLocation(r.prog, 'aPos'),
      aTex: g.getAttribLocation(r.prog, 'aTex'),
    };
    progs.set(key, entry);
    if (progs.size > 60) progs.clear();
  }

  const scale = Math.min(1, MAX_SIDE / Math.max(fw, fh));
  const w = Math.max(1, Math.round(fw * scale));
  const h = Math.max(1, Math.round(fh * scale));

  // La textura se sube a la GPU solo cuando cambia el contenido del sprite (`sig`). Con la
  // imagen fija y el shader animándose por uTime, se sube una sola vez y el resto de frames
  // solo re-renderizan: antes se resubía ~1 MB por personaje y por frame, y de ahí el lag.
  const tkey = (sig ?? '') + '@' + w + 'x' + h;
  let tex = texPool.get(tkey);
  if (!tex) {
    if (!stageCanvas) {
      stageCanvas = document.createElement('canvas');
      stageCtx = stageCanvas.getContext('2d');
    }
    if (stageCanvas.width !== w || stageCanvas.height !== h) {
      stageCanvas.width = w;
      stageCanvas.height = h;
    }
    const sc = stageCtx!;
    sc.clearRect(0, 0, w, h);
    sc.drawImage(src, sx, sy, fw, fh, 0, 0, w, h);
    tex = g.createTexture();
    g.bindTexture(g.TEXTURE_2D, tex);
    g.texImage2D(g.TEXTURE_2D, 0, g.RGBA, g.RGBA, g.UNSIGNED_BYTE, stageCanvas);
    g.texParameteri(g.TEXTURE_2D, g.TEXTURE_MIN_FILTER, g.LINEAR);
    g.texParameteri(g.TEXTURE_2D, g.TEXTURE_MAG_FILTER, g.LINEAR);
    g.texParameteri(g.TEXTURE_2D, g.TEXTURE_WRAP_S, g.CLAMP_TO_EDGE);
    g.texParameteri(g.TEXTURE_2D, g.TEXTURE_WRAP_T, g.CLAMP_TO_EDGE);
    if (sig) {
      texPool.set(tkey, tex);
      if (texPool.size > 80) {
        const oldest = texPool.keys().next().value as string;
        const old = texPool.get(oldest);
        texPool.delete(oldest);
        if (old) g.deleteTexture(old);
      }
    }
  }

  if (glCanvas.width !== w || glCanvas.height !== h) {
    glCanvas.width = w;
    glCanvas.height = h;
  }
  g.viewport(0, 0, w, h);
  g.useProgram(entry.prog);
  g.bindBuffer(g.ARRAY_BUFFER, quadBuf);
  g.enableVertexAttribArray(entry.aPos);
  g.vertexAttribPointer(entry.aPos, 2, g.FLOAT, false, 0, 0);
  g.bindBuffer(g.ARRAY_BUFFER, texBuf);
  g.enableVertexAttribArray(entry.aTex);
  g.vertexAttribPointer(entry.aTex, 2, g.FLOAT, false, 0, 0);
  g.activeTexture(g.TEXTURE0);
  g.bindTexture(g.TEXTURE_2D, tex);
  g.uniform1i(entry.uBitmap, 0);
  g.uniform2f(entry.uSize, w, h);
  g.uniform1f(entry.uTime, time);
  g.clearColor(0, 0, 0, 0);
  g.clear(g.COLOR_BUFFER_BIT);
  g.drawArrays(g.TRIANGLE_STRIP, 0, 4);
  return glCanvas;
}

/** Último error de compilación de un código (para el aviso del editor) */
export function fragError(code: string): string | null {
  const key = code.length + ':' + hashFrag(code);
  return broken.get(key) ?? null;
}
