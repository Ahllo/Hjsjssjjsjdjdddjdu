/**
 * Vista previa del «comportamiento propio». Ejecuta el código Lua de Psych Engine de verdad,
 * no lo adivina: es un intérprete reducido que entiende lo que usan los scripts de escenarios
 * (variables locales con estado entre frames, function onCreate/onUpdate/onBeatHit/onStepHit,
 * if/elseif/else, for y while numéricos, math.*, setProperty/getProperty con el nombre literal
 * del objeto o con TAG .. '.prop', playAnim y los doTween más comunes).
 *
 * El estado (p. ej. `tiempo = tiempo + elapsed * velocidad`) es persistente por comportamiento,
 * así que un movimiento acumulado se ve continuo, igual que en el juego. Lo que exige el motor
 * completo (sonidos, runHaxeCode, shaders…) se reconoce para no dar error y corre tal cual al
 * exportar: el .lua lleva el código escrito por la persona, sin tocar.
 */
import type { LayerValues } from './behaviors';
import { clamp } from './util';

/* ---------------------------------- AST ---------------------------------- */

type Stmt =
  | { k: 'assign'; name: string; expr: string }
  | { k: 'call'; expr: string }
  | { k: 'if'; branches: { cond: string; body: Stmt[] }[]; elseBody?: Stmt[] }
  | { k: 'for'; v: string; from: string; to: string; step?: string; body: Stmt[] }
  | { k: 'while'; cond: string; body: Stmt[] }
  | { k: 'function'; name: string; params: string[]; body: Stmt[] };

/**
 * Quita el comentario `-- …` de una línea, aunque vaya al final detrás del código
 * (`local giro = 40  -- grados por segundo`), respetando lo que haya dentro de comillas.
 */
function stripComment(line: string): string {
  let quote: string | null = null;
  for (let i = 0; i < line.length - 1; i++) {
    const c = line[i];
    if (quote) {
      if (c === quote && line[i - 1] !== '\\') quote = null;
      continue;
    }
    if (c === "'" || c === '"') {
      quote = c;
      continue;
    }
    if (c === '-' && line[i + 1] === '-') return line.slice(0, i).replace(/\s+$/, '');
  }
  return line;
}

/** Parsea por líneas (los scripts de escenarios van a una sentencia por línea) */
function parseBlock(lines: string[], start: number, stop: RegExp): [Stmt[], number] {
  const out: Stmt[] = [];
  let i = start;
  while (i < lines.length) {
    const line = stripComment(lines[i]).trim();
    if (!line) {
      i++;
      continue;
    }
    if (stop.test(line)) return [out, i];

    let m = line.match(/^function\s+([\w.:]+)\s*\(([^)]*)\)\s*$/);
    if (m) {
      const [body, ni] = parseBlock(lines, i + 1, /^end\b/);
      out.push({ k: 'function', name: m[1], params: m[2].split(',').map((s) => s.trim()).filter(Boolean), body });
      i = ni + 1;
      continue;
    }
    m = line.match(/^if\s+([\s\S]+?)\s+then\s*$/);
    if (m) {
      const branches: { cond: string; body: Stmt[] }[] = [];
      let elseBody: Stmt[] | undefined;
      let cond = m[1];
      let j = i + 1;
      for (;;) {
        const [body, ni] = parseBlock(lines, j, /^(elseif\b|else\b|end\b)/);
        branches.push({ cond, body });
        const stopLine = (lines[ni] ?? '').trim();
        const em = stopLine.match(/^elseif\s+([\s\S]+?)\s+then\s*$/);
        if (em) {
          cond = em[1];
          j = ni + 1;
          continue;
        }
        if (/^else\b/.test(stopLine)) {
          const [eb, ni2] = parseBlock(lines, ni + 1, /^end\b/);
          elseBody = eb;
          j = ni2;
        } else {
          j = ni;
        }
        break;
      }
      out.push({ k: 'if', branches, elseBody });
      i = j + 1;
      continue;
    }
    m = line.match(/^for\s+(\w+)\s*=\s*([^,]+),\s*([^,]+?)(?:,\s*([^ ]+?))?\s+do\s*$/);
    if (m) {
      const [body, ni] = parseBlock(lines, i + 1, /^end\b/);
      out.push({ k: 'for', v: m[1], from: m[2].trim(), to: m[3].trim(), step: m[4]?.trim(), body });
      i = ni + 1;
      continue;
    }
    m = line.match(/^while\s+([\s\S]+?)\s+do\s*$/);
    if (m) {
      const [body, ni] = parseBlock(lines, i + 1, /^end\b/);
      out.push({ k: 'while', cond: m[1], body });
      i = ni + 1;
      continue;
    }
    m = line.match(/^(?:local\s+)?(\w+)\s*=\s*([\s\S]+)$/);
    if (m) {
      out.push({ k: 'assign', name: m[1], expr: m[2].trim() });
      i++;
      continue;
    }
    if (/^local\s+\w+\s*$/.test(line)) {
      i++;
      continue;
    }
    // cualquier otra cosa: llamada a función o expresión suelta
    out.push({ k: 'call', expr: line });
    i++;
  }
  return [out, i];
}

/* ------------------------------ interpretación ------------------------------ */

interface Run {
  hash: string;
  scope: Record<string, unknown>;
  funcs: Map<string, { params: string[]; body: Stmt[] }>;
  top: Stmt[];
  inited: boolean;
  layerName: string;
  v: LayerValues;
  anim: string | null;
  lastT: number;
  lastBeat: number;
  lastStep: number;
}

const runs = new Map<string, Run>();
/** funciones ya compiladas por (variables + expresión): evita recompilar con new Function cada frame */
// eslint-disable-next-line @typescript-eslint/no-unsafe-function-type
const exprFnCache = new Map<string, Function>();

function hashCode(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
  return h >>> 0;
}

const truthy = (x: unknown): boolean => x !== false && x !== null && x !== undefined && x !== 0 && x !== '';

function readField(run: Run, p: string): number {
  const v = run.v;
  if (p.endsWith('.scale.x') || p.endsWith('.scaleX')) return v.scaleX;
  if (p.endsWith('.scale.y') || p.endsWith('.scaleY')) return v.scaleY;
  if (p.endsWith('.x')) return v.x;
  if (p.endsWith('.y')) return v.y;
  if (p.endsWith('.alpha')) return v.alpha;
  if (p.endsWith('.angle')) return v.angle;
  if (p.endsWith('.visible')) return v.alpha > 0.01 ? 1 : 0;
  return 0;
}

function writeField(run: Run, p: string, val: unknown) {
  const v = run.v;
  if (p.endsWith('.visible')) {
    v.alpha = truthy(val) ? Math.max(v.alpha, 1) : 0;
    return;
  }
  const n = Number(val);
  if (!isFinite(n)) return;
  if (p.endsWith('.scale.x') || p.endsWith('.scaleX')) v.scaleX = n;
  else if (p.endsWith('.scale.y') || p.endsWith('.scaleY')) v.scaleY = n;
  else if (p.endsWith('.x')) v.x = n;
  else if (p.endsWith('.y')) v.y = n;
  else if (p.endsWith('.alpha')) v.alpha = clamp(n, 0, 1);
  else if (p.endsWith('.angle')) v.angle = n;
}

/** Funciones de Psych que la vista previa sí resuelve; el resto son no-ops para no dar error */
function installApi(run: Run) {
  const s = run.scope;
  s.setProperty = (prop: unknown, val: unknown) => {
    writeField(run, String(prop), val);
    return 0;
  };
  s.getProperty = (prop: unknown) => {
    const p = String(prop);
    if (!p.includes('.')) return run.scope[p] ?? 0;
    if (/^(camGame|camHUD|camOther|camera)/.test(p)) return 0;
    return readField(run, p);
  };
  s.playAnim = (_o: unknown, a: unknown) => {
    run.anim = String(a);
    return 0;
  };
  s.objectPlayAnimation = s.playAnim;
  s.doTweenAlpha = (_t: unknown, _o: unknown, val: unknown) => {
    run.v.alpha = clamp(Number(val), 0, 1);
    return 0;
  };
  s.doTweenAngle = (_t: unknown, _o: unknown, val: unknown) => {
    run.v.angle = Number(val);
    return 0;
  };
  s.doTweenX = (_t: unknown, _o: unknown, val: unknown) => {
    run.v.x = Number(val);
    return 0;
  };
  s.doTweenY = (_t: unknown, _o: unknown, val: unknown) => {
    run.v.y = Number(val);
    return 0;
  };
  s.getRandomInt = (a: unknown, b: unknown) => Math.floor(Math.random() * (Number(b) - Number(a) + 1)) + Number(a);
  s.getRandomBool = (p: unknown) => (Math.random() * 100 < Number(p) ? 1 : 0);
  s.getColorFromHex = (h: unknown) => parseInt(String(h).replace(/^#|^0x/i, ''), 16) || 0;
  const noops = [
    'makeLuaSprite', 'addLuaSprite', 'removeLuaSprite', 'makeAnimatedLuaSprite', 'makeLuaText', 'addLuaText',
    'removeLuaText', 'addAnimationByPrefix', 'playSound', 'stopSound', 'soundFadeIn', 'soundFadeOut',
    'runHaxeCode', 'runHaxeFunction', 'setScrollFactor', 'setObjectCamera', 'setObjectOrder', 'addOffset',
    'triggerEvent', 'triggerEventLuas', 'debugPrint', 'noteTweenX', 'noteTweenY', 'noteTweenAngle',
    'noteTweenAlpha', 'noteTweenColor', 'screenCenter', 'getMouseX', 'getMouseY', 'keyPressed',
    'keyJustPressed', 'setGraphicSize', 'updateHitbox', 'scaleObject', 'addCharacterToList', 'characterDance',
  ];
  for (const n of noops) s[n] = () => 0;
}

/** Evalúa una expresión Lua con las variables del scope inyectadas (math→Math, and/or/not, ..) */
function evalExpr(expr: string, run: Run): unknown {
  let e = expr.trim();
  e = e
    .replace(/\bmath\.(\w+)/g, 'Math.$1')
    .replace(/~=/g, '!=')
    .replace(/\band\b/g, '&&')
    .replace(/\bor\b/g, '||')
    .replace(/\bnot\b/g, '!')
    .replace(/\.\./g, '+')
    .replace(/\^/g, '**')
    .replace(/\bnil\b/g, 'null');
  const names = Object.keys(run.scope).filter((n) => /^[$A-Za-z_]\w*$/.test(n));
  // new Function() compila: hacerlo cada frame por cada expresión era una fuente de lag.
  // La función compilada se cachea por (variables + expresión) y se reutiliza.
  const fkey = names.join('\u0000') + '\u0001' + e;
  let fn = exprFnCache.get(fkey);
  if (!fn) {
    try {
      fn = new Function(...names, '"use strict";return (' + e + ');');
    } catch {
      return undefined;
    }
    exprFnCache.set(fkey, fn);
    if (exprFnCache.size > 600) exprFnCache.clear();
  }
  try {
    return fn(...names.map((n) => run.scope[n]));
  } catch {
    return undefined;
  }
}

function execBlock(stmts: Stmt[], run: Run) {
  for (const s of stmts) execStmt(s, run);
}

function execStmt(s: Stmt, run: Run) {
  switch (s.k) {
    case 'assign': {
      const val = evalExpr(s.expr, run);
      if (val !== undefined) run.scope[s.name] = val;
      break;
    }
    case 'call':
      evalExpr(s.expr, run);
      break;
    case 'if': {
      for (const br of s.branches) {
        if (truthy(evalExpr(br.cond, run))) {
          execBlock(br.body, run);
          return;
        }
      }
      if (s.elseBody) execBlock(s.elseBody, run);
      break;
    }
    case 'for': {
      const from = Number(evalExpr(s.from, run));
      const to = Number(evalExpr(s.to, run));
      const step = s.step ? Number(evalExpr(s.step, run)) : 1;
      if (!isFinite(from) || !isFinite(to) || !isFinite(step) || step === 0) break;
      const guard = step > 0 ? (i: number) => i <= to : (i: number) => i >= to;
      for (let i = from; guard(i); i += step) {
        run.scope[s.v] = i;
        execBlock(s.body, run);
      }
      break;
    }
    case 'while': {
      let n = 0;
      while (truthy(evalExpr(s.cond, run)) && n++ < 10000) execBlock(s.body, run);
      break;
    }
    case 'function':
      break;
  }
}

function callFunc(run: Run, name: string, args: unknown[]) {
  const f = run.funcs.get(name);
  if (!f) return;
  const saved = f.params.map((p) => run.scope[p]);
  f.params.forEach((p, i) => (run.scope[p] = args[i]));
  execBlock(f.body, run);
  f.params.forEach((p, i) => (run.scope[p] = saved[i]));
}

function buildRun(code: string, hash: string): Run {
  const [top] = parseBlock(code.split(/\r?\n/), 0, /^\u0000$/);
  const funcs = new Map<string, { params: string[]; body: Stmt[] }>();
  const rest: Stmt[] = [];
  for (const s of top) {
    if (s.k === 'function') funcs.set(s.name, { params: s.params, body: s.body });
    else rest.push(s);
  }
  const run: Run = {
    hash,
    scope: {},
    funcs,
    top: rest,
    inited: false,
    layerName: '',
    v: { x: 0, y: 0, angle: 0, alpha: 1, scaleX: 1, scaleY: 1 },
    anim: null,
    lastT: 0,
    lastBeat: -1,
    lastStep: -1,
  };
  installApi(run);
  return run;
}

/**
 * Avanza un frame del comportamiento propio sobre `v` (los valores de la capa). Devuelve la
 * animación si el código la cambió con playAnim. `t` va hacia atrás al recolocar/scrubear,
 * en ese caso la simulación se reinicia para no arrastrar estado viejo.
 */
export function runCustomBehavior(id: string, code: string, layerName: string, v: LayerValues, t: number, beatLen: number): string | null {
  const hash = code.length + ':' + hashCode(code);
  let run = runs.get(id);
  if (!run || run.hash !== hash) {
    run = buildRun(code, hash);
    runs.set(id, run);
  }
  if (runs.size > 300) runs.clear();
  if (t < run.lastT) run.inited = false; // scrub hacia atrás: reinicia
  const elapsed = clamp(t - run.lastT, 0, 0.1);
  run.lastT = t;
  run.v = v;
  run.anim = null;
  run.layerName = layerName;

  const beat = Math.max(0, Math.floor(t / beatLen));
  const step = Math.floor(t / (beatLen / 4));
  Object.assign(run.scope, {
    t,
    elapsed,
    curBeat: beat,
    curStep: step,
    crochet: beatLen * 1000,
    stepCrochet: beatLen * 250,
    bpm: 60 / beatLen,
    beatJustHit: t / beatLen - beat < 0.15,
    TAG: layerName,
  });

  if (!run.inited) {
    execBlock(run.top, run);
    callFunc(run, 'onCreate', []);
    callFunc(run, 'onCreatePost', []);
    run.inited = true;
    run.lastBeat = beat;
    run.lastStep = step;
  }
  callFunc(run, 'onUpdate', [elapsed]);
  if (beat !== run.lastBeat) {
    callFunc(run, 'onBeatHit', []);
    run.lastBeat = beat;
  }
  if (step !== run.lastStep) {
    callFunc(run, 'onStepHit', []);
    run.lastStep = step;
  }
  return run.anim;
}
