import type { Behavior, BehaviorType, Layer, Project } from '../types';
import { newBehavior } from './defaults';

type Beh = Partial<Behavior> & { type: BehaviorType };

/**
 * Mecánicas que los escenarios de Psych Engine y P-Slice programan en su .lua y que el
 * .json no cuenta: el tren de Philly, las ventanas que cambian de color, lo que se
 * desplaza sin parar, lo que gira, lo que flota, el público que baila.
 *
 * Esto es un PASO EXTRA de la importación, no un sustituto: solo añade comportamientos a
 * las capas que todavía no tengan ninguno, así que nunca pisa lo que el importador ya
 * haya traducido del JSON o del propio Lua. Tampoco toca los shaders —de esos se encarga
 * applyShadersFromLua, que sigue funcionando exactamente igual.
 */

export interface LuaBehaviorReport {
  /** cuántos comportamientos se añadieron */
  count: number;
  /** qué se reconoció, para el aviso ("tren en bgTrain → pasa de vez en cuando") */
  detail: string[];
  /** pistas de lo que se ve en el script pero no se sabe traducir */
  warnings: string[];
}

/** Quita los comentarios de Lua (los de bloque y los de línea) sin tocar las cadenas */
function strip(lua: string): string {
  return lua.replace(/--\[(=*)\[[\s\S]*?\]\1\]/g, ' ').replace(/--(?!\[\[)[^\n]*/g, ' ');
}

/** Texto de una función del script, hasta su `end` a columna cero */
function section(src: string, head: RegExp): string {
  const m = src.match(head);
  if (!m || m.index === undefined) return '';
  const rest = src.slice(m.index);
  const end = rest.search(/\nend\b/);
  return end < 0 ? rest : rest.slice(0, end);
}

const n = (v: string | undefined, d: number) => {
  const f = parseFloat(v ?? '');
  return isFinite(f) ? f : d;
};

/** Colores de una lista tipo lightColors = {0xFFB66F43, …} o {'31A2FD', …} */
function colorList(src: string): string[] {
  const line = src.split('\n').find((l) => /(lightColors|windowColors|colors\s*=)/i.test(l));
  if (!line) return [];
  const out: string[] = [];
  for (const m of line.matchAll(/0x[0-9a-f]{2}([0-9a-f]{6})/gi)) out.push(m[1].toUpperCase());
  if (!out.length) for (const m of line.matchAll(/['"]#?([0-9a-f]{6})['"]/gi)) out.push(m[1].toUpperCase());
  return out;
}

/** Líneas del script que mencionan esta capa (por su nombre o su etiqueta) */
function linesFor(src: string, layer: Layer): string[] {
  const esc = layer.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return src.match(new RegExp(`^.*\\b${esc}\\b.*$`, 'gim')) ?? [];
}

interface Ctx {
  all: string;
  beat: string;
  update: string;
}

/** Un detector por mecánica; devuelven el comportamiento o null si no la reconocen */
const DETECTORS: { label: string; run: (l: Layer, own: string, ctx: Ctx) => Beh | null }[] = [
  {
    // PhillyTrain.hx / PhillyTrainErect: beat % 8 == 4, 30%, cooldown > 8, 8 vagones, 4.7 s de audio
    label: 'tren que pasa',
    run: (l, own, ctx) => {
      const s = ctx.all;
      if (!/train_passes|trainCars|trainMoving|trainSound/i.test(s)) return null;
      if (!/train|tren/i.test(l.name) && !/train/i.test(own)) return null;
      const beatMod = s.match(/curBeat\s*%\s*(\d+)\s*==\s*(\d+)/i);
      const cars = s.match(/trainCars\s*(?::\s*Int)?\s*=\s*(\d+)/i);
      const chance = s.match(/(?:random\.bool|getRandomBool)\s*\(\s*(\d+)/i);
      const startX = own.match(/\.x\s*=\s*FlxG\.width\s*\+\s*(\d+)/) ?? own.match(/\.x\s*=\s*(-?\d{3,})/);
      return {
        type: 'passBy',
        every: n(beatMod?.[1], 8),
        phase: n(beatMod?.[2], 4),
        chance: n(chance?.[1], 30),
        cooldown: 8,
        speed: 9600,
        startX: n(startX?.[1], l.x || 2000),
        endX: -2000,
        loopX: -1150,
        finishX: -4000,
        repeats: n(cars?.[1], 8),
        delay: 4.7,
        sound: 'train_passes',
        gfHair: true,
      };
    },
  },
  {
    // Limo.hx: el coche cruza una vez de vez en cuando, a toda velocidad y sin vagones
    label: 'coche que cruza',
    run: (l, own, ctx) => {
      if (!/fastCar|carPass|limoCar/i.test(ctx.all)) return null;
      if (!/car|coche|limo/i.test(l.name) && !/car/i.test(own)) return null;
      return { type: 'passBy', startX: l.x || -12600, finishX: 3000, speed: 35000, repeats: 0, chance: 10, every: 1, phase: 0, cooldown: 0, gfHair: false, delay: 0, sound: '', randomAnim: false };
    },
  },
  {
    // Philly: cada N beats la ventana toma un color al azar de la lista y se va apagando
    label: 'luces que cambian',
    run: (l, own, ctx) => {
      const cols = colorList(ctx.all);
      const isWindow = /light|win|ventana|window/i.test(l.name) || /lightWindow|curLight/i.test(own);
      if (!cols.length || !isWindow) return null;
      const every = ctx.beat.match(/curBeat\s*%\s*(\d+)\s*==\s*0/i) ?? ctx.all.match(/curBeat\s*%\s*(\d+)\s*==\s*0/i);
      return { type: 'lightCycle', every: n(every?.[1], 4), amount: 1, colors: cols.join(', ') };
    },
  },
  {
    // GF baila alternando; el público de la week 5 y los tanquistas hacen lo mismo
    label: 'baile izq/der',
    run: (_l, own) => {
      if (!/danceLeft/i.test(own) || !/danceRight/i.test(own)) return null;
      return { type: 'danceLR', anim: 'danceLeft', anim2: 'danceRight', every: 1 };
    },
  },
  {
    // movimiento continuo por frame: x = x + elapsed * N (nubes de la week 7, fondos)
    label: 'desplazamiento continuo',
    // `own` ya son las líneas de TODO el script que mencionan esta capa (onUpdate incluido),
    // así que no se mira el resto: si no, el movimiento de otra capa se le pegaba a esta.
    // Las líneas con math.sin/cos son un vaivén, no un desplazamiento: las descarta.
    run: (_l, own, _ctx) => {
      const plain = own
        .split('\n')
        .filter((x) => !/math\.(sin|cos)/i.test(x))
        .join('\n');
      const vx = plain.match(/\.x\b[^\n]*?elapsed\s*\*\s*(-?[\d.]+)/);
      const vy = plain.match(/\.y\b[^\n]*?elapsed\s*\*\s*(-?[\d.]+)/);
      const va = own.match(/\.angle\b[^\n]*?elapsed\s*\*\s*(-?[\d.]+)/);
      if (va) return { type: 'spin', speed: n(va[1], 45) };
      if (!vx && !vy) return null;
      return { type: 'scroll', speed: vx ? n(vx[1], 0) : 0, speedY: vy ? n(vy[1], 0) : 0, range: 0 };
    },
  },
  {
    // giro con tween: doTweenAngle(tag, tag, 360, D, …) → grados por segundo
    label: 'giro con tween',
    run: (_l, own) => {
      const m = own.match(/doTweenAngle\([^,]+,[^,]+,\s*(-?[\d.]+)\s*,\s*([\d.]+)/i);
      if (!m) return null;
      const deg = n(m[1], 360);
      const dur = n(m[2], 0);
      if (!dur) return null;
      return { type: 'spin', speed: Math.round((deg / dur) * 100) / 100 };
    },
  },
  {
    // vaivén senoidal: math.sin(… * elapsed/time …) * AMP sobre y (o x)
    label: 'flotando',
    run: (_l, own, _ctx) => {
      const m = own.match(/math\.sin\(([^)]*)\)\s*\*\s*(-?[\d.]+)/i);
      if (!m) return null;
      const amp = n(m[2], 0);
      if (!amp) return null;
      const axis: 'x' | 'y' = /\.x\b[^\n]*math\.sin/i.test(own) ? 'x' : 'y';
      // math.sin(K * elapsed) va en radianes por segundo: el periodo son 2π / K
      const arg = m[1];
      const k = arg.match(/([\d.]+)\s*\*\s*(?:elapsed|\bt\b|time)/i) ?? arg.match(/(?:elapsed|\bt\b|time)\s*\*\s*([\d.]+)/i);
      const hz = n(k?.[1], 0);
      return { type: 'float', axis, amount: Math.abs(amp), period: hz > 0 ? Math.round(((Math.PI * 2) / hz) * 100) / 100 : 2 };
    },
  },
  {
    // público y adornos que hacen bop en cada beat (week 5, week 7)
    label: 'bop en cada beat',
    run: (l, _own, ctx) => {
      if (!ctx.beat) return null;
      const inBeat = linesFor(ctx.beat, l).join('\n');
      if (!inBeat) return null;
      if (/doTweenAngle|\.angle\s*=/i.test(inBeat)) return { type: 'beatBump', prop: 'angle', amount: 8, every: 1, decay: 7 };
      if (/scale\.x|scaleX|doTweenZoom/i.test(inBeat)) return { type: 'beatBump', prop: 'scale', amount: 0.06, every: 1, decay: 7 };
      if (/playAnim|objectPlayAnimation|animation\.play/i.test(inBeat)) {
        const anim = inBeat.match(/(?:playAnim|objectPlayAnimation)\([^,]+,\s*['"]([^'"]+)['"]/i);
        return { type: 'beatAnim', anim: anim?.[1] ?? 'idle', every: 1 };
      }
      return null;
    },
  },
];

export function applyLuaBehaviors(project: Project, lua: string): LuaBehaviorReport {
  const src = strip(lua);
  const ctx: Ctx = {
    all: src,
    beat: section(src, /function\s+onBeatHit/),
    update: section(src, /function\s+onUpdate/),
  };
  const detail: string[] = [];
  const warnings: string[] = [];
  let count = 0;

  for (const l of project.layers) {
    // solo a las que no tengan nada: lo ya traducido manda
    if (l.kind === 'gf' || l.kind === 'dad' || l.kind === 'boyfriend') continue;
    if (l.behaviors.some((b) => b.enabled)) continue;
    const own = linesFor(src, l).join('\n');
    if (!own) continue;
    for (const d of DETECTORS) {
      let beh: Beh | null = null;
      try {
        beh = d.run(l, own, ctx);
      } catch {
        continue;
      }
      if (!beh) continue;
      l.behaviors.push(newBehavior(beh.type, beh));
      count++;
      detail.push(`${l.name} → ${d.label}`);
      break;
    }
  }

  // avisos honestos de lo que se ve en el script y no se sabe traducir
  if (/RainShader|initLuaShader|setShaderSampler2D/i.test(src) && !/adjustColor|dropShadow/i.test(src))
    warnings.push('El .lua usa shaders propios que no son AdjustColor ni DropShadow: no se traducen.');
  if (/cutscene|camCutscene|startVideo|triggerEvent\(/i.test(src)) warnings.push('El .lua tiene cutscenes o eventos de canción, que viven fuera del escenario.');
  if (/FlxTiledSprite|FlxBackdrop|makeGraphic/i.test(src)) warnings.push('Hay fondos en mosaico o rectángulos sólidos creados por código.');
  return { count, detail, warnings };
}
