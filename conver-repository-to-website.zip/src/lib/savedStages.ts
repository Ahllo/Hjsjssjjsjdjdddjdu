import { del as idbDel, get as idbGet, set as idbSet } from 'idb-keyval';
import { useEditor } from '../store';
import type { Project, SavedStage, StageCategory } from '../types';
import { ensureRuntime, exportProjectFile, importProjectFile } from './assets';
import { CAT_COLORS } from './charlib';
import { CHAR_KEYS, isCharKind } from './defaults';
import { buildDrawables, drawDrawable, type Drawable, type SceneOpts, type ViewCam } from './render';
import { downloadBlob, uid } from './util';

/**
 * Biblioteca de escenarios del usuario: guarda el proyecto que tengas abierto ahora
 * mismo (uno hecho desde cero, un oficial retocado o un Erect) con todas sus imágenes,
 * y lo organiza en categorías propias, igual que la biblioteca de personajes.
 *
 * Cada guardado es autocontenido: resetAll() borra los recursos sueltos de IndexedDB al
 * abrir otro escenario, así que el paquete (.psychstage) se guarda aparte bajo su propia
 * clave y sobrevive a lo que hagas después.
 */

const LIST_KEY = 'savedstages';
const CATS_KEY = 'stagecats';
const blobKey = (id: string) => 'stageblob:' + id;

let loaded = false;
let loading: Promise<void> | null = null;

async function readStore() {
  const list = ((await idbGet(LIST_KEY)) as SavedStage[] | undefined) ?? [];
  const cats = ((await idbGet(CATS_KEY)) as StageCategory[] | undefined) ?? [];
  // un escenario cuya categoría ya no existe vuelve a "Sin categoría" en vez de romperse
  const ids = new Set(cats.map((c) => c.id));
  useEditor.setState({
    savedStages: list.map((s) => (s.catId && !ids.has(s.catId) ? { ...s, catId: undefined } : s)),
    stageCats: cats,
  });
}

/** Carga la biblioteca una sola vez; lo llama el panel de escenarios al abrirse */
export function ensureSavedStages(): Promise<void> {
  if (loaded) return Promise.resolve();
  if (!loading)
    loading = (async () => {
      try {
        await readStore();
      } catch {
        /* sin nada guardado todavía */
      } finally {
        loaded = true;
      }
    })();
  return loading;
}

function setList(list: SavedStage[]) {
  useEditor.setState({ savedStages: list });
  idbSet(LIST_KEY, list).catch(() => useEditor.setState({ storageWarning: true }));
}

function setCats(cats: StageCategory[]) {
  useEditor.setState({ stageCats: cats });
  idbSet(CATS_KEY, cats).catch(() => useEditor.setState({ storageWarning: true }));
}

/**
 * Miniatura del escenario COMPLETO. No es una captura del lienzo —que solo enseña lo que
 * cabe en la ventana, con su rejilla y sus guías—: compone todas las capas con el mismo
 * renderizador de la vista previa y las encuadra enteras, de punta a punta.
 *
 * Se hace en dos pasadas: una con la cámara en la identidad para medir hasta dónde llega
 * el escenario, y otra con la cámara que lo encuadra todo. Los shaders .frag se omiten a
 * propósito: se procesan en CPU a resolución completa y a 208 px de alto no se aprecian,
 * así que quitarlos hace que guardar sea instantáneo. Los tintes de color sí se mantienen.
 */
export async function makeStageThumb(w = 560, h = 208): Promise<string | undefined> {
  try {
    const st = useEditor.getState();
    // los recursos se cargan de forma perezosa: sin esto, las capas que aún no se han
    // dibujado en pantalla saldrían como huecos en la miniatura
    await Promise.all(st.assets.map((a) => ensureRuntime(a.id)));
    const project: Project = {
      ...st.project,
      layers: st.project.layers.map((l) => ({ ...l, shader: null })),
      characters: Object.fromEntries(
        CHAR_KEYS.map((k) => [k, { ...st.project.characters[k], shader: null }]),
      ) as Project['characters'],
    };
    const base: SceneOpts = {
      project,
      assets: st.assets,
      time: 0,
      playing: false,
      lowQuality: false,
      storyMode: false,
      gameView: true,
      hudFrame: { left: 0, top: 0, vs: 1 },
      cam: { cx: 0, cy: 0, s: 1, ox: 0, oy: 0, parallax: false },
    };
    /**
     * Qué entra en la miniatura: solo lo que ve la cámara del juego (las capas de HUD viven
     * en otro espacio de coordenadas y descuadrarían el encuadre) y sin las siluetas de los
     * puestos vacíos, que no dicen nada del escenario.
     */
    const keep = (d: Drawable) => d.layer.camera === 'game' && !(d.placeholder && isCharKind(d.layer.kind));

    const first = buildDrawables(base).filter(keep);
    if (!first.length) return undefined;
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    for (const d of first) {
      const corners: [number, number][] = [
        [0, 0],
        [d.fw, 0],
        [0, d.fh],
        [d.fw, d.fh],
      ];
      for (const [px, py] of corners) {
        const p = d.box.transformPoint(new DOMPoint(px, py));
        if (p.x < minX) minX = p.x;
        if (p.x > maxX) maxX = p.x;
        if (p.y < minY) minY = p.y;
        if (p.y > maxY) maxY = p.y;
      }
    }
    const bw = maxX - minX;
    const bh = maxY - minY;
    if (!isFinite(bw) || !isFinite(bh) || bw < 1 || bh < 1) return undefined;

    const s = Math.min(w / bw, h / bh);
    const cam: ViewCam = { cx: (minX + maxX) / 2, cy: (minY + maxY) / 2, s, ox: w / 2, oy: h / 2, parallax: false };
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const g = c.getContext('2d');
    if (!g) return undefined;
    const bg = g.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, '#120d24');
    bg.addColorStop(1, '#08060f');
    g.fillStyle = bg;
    g.fillRect(0, 0, w, h);
    for (const d of buildDrawables({ ...base, cam }).filter(keep)) drawDrawable(g, d, 1);
    g.setTransform(1, 0, 0, 1, 0, 0);
    g.globalAlpha = 1;
    g.globalCompositeOperation = 'source-over';
    return c.toDataURL('image/jpeg', 0.8);
  } catch {
    return undefined;
  }
}

/** Color de arranque para una categoría nueva; después se cambia libremente */
export const suggestCatColor = () => START_COLORS[useEditor.getState().stageCats.length % START_COLORS.length];

/** Guarda el proyecto abierto ahora mismo con el nombre, la descripción, el color y la categoría que le digas */
export async function saveCurrentStage(name: string, catId: string | null, desc?: string, color?: string, badge?: string): Promise<SavedStage> {
  const st = useEditor.getState();
  const clean = name.trim().replace(/\s+/g, ' ').slice(0, 40) || st.project.settings.name || 'Escenario';
  const blob = await exportProjectFile();
  const id = 'stage:' + uid();
  try {
    await idbSet(blobKey(id), blob);
  } catch {
    useEditor.setState({ storageWarning: true });
    throw new Error('El navegador no tiene espacio para guardar este escenario');
  }
  const p = st.project;
  const entry: SavedStage = {
    id,
    name: clean,
    desc: desc?.trim().replace(/\s+/g, ' ').slice(0, 140) || undefined,
    color: color && color.trim() ? hex(color) : undefined,
    badge: word(badge, 18),
    catId: catId ?? undefined,
    thumb: await makeStageThumb(),
    bytes: blob.size,
    layers: p.layers.filter((l) => !isCharKind(l.kind)).length,
    zoom: p.settings.defaultZoom,
    target: p.settings.target,
    directory: p.settings.directory,
    savedAt: Date.now(),
  };
  setList([entry, ...useEditor.getState().savedStages]);
  return entry;
}

/** Abre un escenario guardado: reemplaza el proyecto actual, como hacer doble clic en su archivo */
export async function openSavedStage(id: string): Promise<string> {
  const entry = useEditor.getState().savedStages.find((s) => s.id === id);
  if (!entry) throw new Error('Ese escenario ya no está en la biblioteca');
  const blob = (await idbGet(blobKey(id))) as Blob | undefined;
  if (!blob) throw new Error(`Se perdió el paquete guardado de "${entry.name}"`);
  await importProjectFile(await blob.text());
  return entry.name;
}

export async function deleteSavedStage(id: string) {
  setList(useEditor.getState().savedStages.filter((s) => s.id !== id));
  try {
    await idbDel(blobKey(id));
  } catch {
    /* ya se limpiará solo */
  }
}

export function renameSavedStage(id: string, name: string): boolean {
  const clean = name.trim().replace(/\s+/g, ' ').slice(0, 40);
  if (!clean) return false;
  setList(useEditor.getState().savedStages.map((s) => (s.id === id ? { ...s, name: clean } : s)));
  return true;
}

/** Texto suelto normalizado; devuelve undefined si queda vacío, que es "que no esté" */
const word = (v: string | undefined, max: number) => {
  const c = (v ?? '').trim().replace(/\s+/g, ' ').slice(0, max);
  return c || undefined;
};

/** Nombre, descripción, color, insignia y categoría de un escenario guardado */
export function updateSavedStage(
  id: string,
  patch: { name?: string; desc?: string; color?: string; badge?: string; catId?: string | null },
): boolean {
  if (patch.name !== undefined && !patch.name.trim()) return false;
  setList(
    useEditor.getState().savedStages.map((s) =>
      s.id === id
        ? {
            ...s,
            ...(patch.name !== undefined ? { name: patch.name.trim().replace(/\s+/g, ' ').slice(0, 40) } : {}),
            ...(patch.desc !== undefined ? { desc: patch.desc.trim().replace(/\s+/g, ' ').slice(0, 140) || undefined } : {}),
            ...(patch.color !== undefined ? { color: patch.color.trim() ? hex(patch.color) : undefined } : {}),
            ...(patch.badge !== undefined ? { badge: word(patch.badge, 18) } : {}),
            ...(patch.catId !== undefined ? { catId: patch.catId ?? undefined } : {}),
          }
        : s,
    ),
  );
  return true;
}

/** Vuelve a generar la miniatura de un escenario guardado con el proyecto abierto ahora */
export async function refreshStageThumb(id: string): Promise<string | null> {
  const thumb = await makeStageThumb();
  if (!thumb) return null;
  setList(useEditor.getState().savedStages.map((s) => (s.id === id ? { ...s, thumb } : s)));
  return thumb;
}

/** Mueve un escenario a una categoría (null lo saca de todas) */
export function setStageCategory(id: string, catId: string | null) {
  setList(useEditor.getState().savedStages.map((s) => (s.id === id ? { ...s, catId: catId ?? undefined } : s)));
}

/** Baja el escenario como archivo .psychstage, para compartirlo o tenerlo de copia */
export async function exportSavedStageFile(id: string): Promise<boolean> {
  const entry = useEditor.getState().savedStages.find((s) => s.id === id);
  const blob = entry ? ((await idbGet(blobKey(id))) as Blob | undefined) : undefined;
  if (!entry || !blob) return false;
  downloadBlob(blob, entry.name.replace(/[^\w\-. ]+/g, '_').trim() + '.psychstage');
  return true;
}

/* ------------------------- categorías de escenarios ------------------------- */

const hex = (c: string) => c.replace(/^#/, '').toUpperCase();
/** Color en CSS a partir del hex guardado (sin almohadilla) */
export const cssColor = (c: string) => '#' + hex(c || '10B981');

/** Solo punto de partida: después el color se cambia libremente con el selector */
const START_COLORS = CAT_COLORS.map((c) => hex(c));

export function createStageCategory(name: string, color?: string, desc?: string): StageCategory | null {
  const clean = name.trim().replace(/\s+/g, ' ').slice(0, 28);
  if (!clean) return null;
  const cats = useEditor.getState().stageCats;
  if (cats.some((c) => c.name.trim().toLowerCase() === clean.toLowerCase())) return null;
  const cat: StageCategory = {
    id: 'scat:' + uid(),
    name: clean,
    color: color ? hex(color) : START_COLORS[cats.length % START_COLORS.length],
    desc: desc?.trim() || undefined,
    addedAt: Date.now(),
  };
  setCats([...cats, cat]);
  return cat;
}

/** Renombra, recolorea o reescribe la descripción de una categoría (todo a la vez o por separado) */
export function updateStageCategory(id: string, patch: { name?: string; color?: string; desc?: string }): boolean {
  const cats = useEditor.getState().stageCats;
  if (patch.name !== undefined) {
    const clean = patch.name.trim().replace(/\s+/g, ' ').slice(0, 28);
    if (!clean) return false;
    if (cats.some((c) => c.id !== id && c.name.trim().toLowerCase() === clean.toLowerCase())) return false;
    patch = { ...patch, name: clean };
  }
  setCats(
    cats.map((c) =>
      c.id === id
        ? {
            ...c,
            ...(patch.name !== undefined ? { name: patch.name } : {}),
            ...(patch.color !== undefined ? { color: hex(patch.color) } : {}),
            ...(patch.desc !== undefined ? { desc: patch.desc.trim().slice(0, 140) || undefined } : {}),
          }
        : c,
    ),
  );
  return true;
}

/** Borra la categoría; sus escenarios NO se borran, vuelven a "Sin categoría" */
export function deleteStageCategory(id: string) {
  setCats(useEditor.getState().stageCats.filter((c) => c.id !== id));
  setList(useEditor.getState().savedStages.map((s) => (s.catId === id ? { ...s, catId: undefined } : s)));
}

export function stageCatCounts(list: SavedStage[]): Map<string, number> {
  const m = new Map<string, number>();
  for (const s of list) if (s.catId) m.set(s.catId, (m.get(s.catId) ?? 0) + 1);
  return m;
}

export const savedBytes = (list: SavedStage[]) => list.reduce((n, s) => n + (s.bytes || 0), 0);

/** "hace 5 min" / "ayer" / "12 mar" para la ficha del escenario */
export function relTime(ts: number): string {
  const s = Math.max(0, (Date.now() - ts) / 1000);
  if (s < 60) return 'ahora mismo';
  const m = Math.floor(s / 60);
  if (m < 60) return `hace ${m} min`;
  const h = Math.floor(m / 60);
  if (h < 24) return `hace ${h} h`;
  const d = Math.floor(h / 24);
  if (d === 1) return 'ayer';
  if (d < 30) return `hace ${d} días`;
  return new Date(ts).toLocaleDateString('es', { day: 'numeric', month: 'short', year: '2-digit' });
}
