import { useState } from 'react';
import { Plus, Trash2, UserRound, Users, X } from 'lucide-react';
import { useEditor } from '../store';
import type { CharLibEntry, ExtraChar } from '../types';
import { newExtraChar } from '../lib/defaults';
import { Btn, IconBtn, NumberInput, TextInput, Toggle } from './ui';
import { cn } from '../utils/cn';

/**
 * Personajes extras: cantantes aparte de BF / GF / DAD (un corista, un invitado…). Comparten
 * la biblioteca de personajes, se arrastran en el lienzo como los de siempre y en el chart
 * cantan con el evento «Cantar extra».
 */
export default function ExtrasPanel() {
  const extraChars = useEditor((s) => s.project.extraChars);
  const charLib = useEditor((s) => s.charLib);
  const selectedId = useEditor((s) => s.selectedId);
  const commit = useEditor((s) => s.commit);
  const [picking, setPicking] = useState<string | null>(null);

  const list = extraChars ?? [];
  const pickingExtra = list.find((e) => e.id === picking) ?? null;

  const addExtra = () =>
    commit((d) => {
      d.extraChars = [...(d.extraChars ?? []), newExtraChar({ name: 'extra' + ((d.extraChars?.length ?? 0) + 1) })];
    }, 'addExtra');
  const upd = (id: string, patch: Partial<ExtraChar>) =>
    commit((d) => {
      const e = (d.extraChars ?? []).find((x) => x.id === id);
      if (e) Object.assign(e, patch);
    }, 'extra:' + id + ':' + Object.keys(patch).join());
  const del = (id: string) =>
    commit((d) => {
      d.extraChars = (d.extraChars ?? []).filter((x) => x.id !== id);
    }, 'delExtra');
  const assign = (ec: ExtraChar, entry: CharLibEntry) => {
    upd(ec.id, { custom: structuredClone(entry.char) });
    setPicking(null);
  };
  const libOf = (ec: ExtraChar): CharLibEntry | undefined => (ec.custom ? charLib.find((e) => e.char.fileName === ec.custom!.fileName) : undefined);

  return (
    <div className="space-y-3">
      <p className="text-[11px] leading-snug text-white/50">
        Cantantes aparte de BF / GF / DAD —un corista, un invitado, los que quieras—. Comparten tu biblioteca de personajes: elige quién es
        cada uno y <b className="text-white/75">arrástralo en el lienzo</b> para colocarlo (o usa X/Y). En el chart, el evento{' '}
        <b className="text-amber-200">«Cantar extra»</b> (value1 = su nombre · value2 = singLEFT, singRIGHT, singUP, singDOWN o idle) lo hace
        cantar cuando quieras.
      </p>

      {list.map((ec) => {
        const lib = libOf(ec);
        const selected = selectedId === 'xchar_' + ec.id;
        return (
          <div
            key={ec.id}
            className={cn('space-y-2.5 rounded-2xl border p-3 transition', selected ? 'border-amber-400/70 bg-amber-500/[0.07]' : 'border-white/10 bg-white/[0.03]')}
          >
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPicking(ec.id)}
                title="Elegir quién es"
                className="relative flex h-12 w-12 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-white/10 bg-[#141024] transition active:scale-95"
              >
                {lib?.iconData || lib?.thumb ? (
                  <img src={(lib.iconData ?? lib.thumb)!} alt="" className="h-full w-full object-cover" draggable={false} />
                ) : (
                  <UserRound size={20} className="text-white/30" />
                )}
                <span className="absolute inset-x-0 bottom-0 bg-black/65 py-px text-center text-[8px] font-bold uppercase tracking-wide text-amber-200">
                  quién es
                </span>
              </button>
              <div className="min-w-0 flex-1">
                <TextInput value={ec.name} onCommit={(v) => upd(ec.id, { name: v.trim().replace(/[^A-Za-z0-9_\-]/g, '_') || 'extra' })} mono />
                <p className="mt-0.5 truncate text-[10px] text-white/40">
                  {ec.custom ? `${ec.custom.fileName} · ${ec.custom.animations.length} anims` : 'sin personaje · toca la foto para elegirlo'}
                </p>
              </div>
              <IconBtn title="Quitar este personaje extra" onClick={() => del(ec.id)}>
                <Trash2 size={14} />
              </IconBtn>
            </div>
            <div className="grid grid-cols-3 gap-2">
              <NumberInput label="X" value={ec.x} onChange={(v) => upd(ec.id, { x: v })} step={10} precision={0} />
              <NumberInput label="Y" value={ec.y} onChange={(v) => upd(ec.id, { y: v })} step={10} precision={0} />
              <NumberInput label="Escala" value={ec.scale} onChange={(v) => upd(ec.id, { scale: Math.max(0.05, v) })} step={0.05} precision={2} />
            </div>
            <Toggle checked={ec.flipX} onChange={(v) => upd(ec.id, { flipX: v })} label="Voltear horizontalmente" />
          </div>
        );
      })}

      <Btn variant="soft" className="w-full" onClick={addExtra}>
        <Plus size={15} /> Añadir personaje extra
      </Btn>
      {!list.length && (
        <p className="rounded-xl border border-dashed border-white/15 bg-black/20 p-4 text-center text-[11px] leading-snug text-white/40">
          No hay personajes extra. Añade uno, elige quién es desde tu biblioteca (la misma de BF / GF / DAD) y arrástralo en el lienzo.
        </p>
      )}

      {/* elegir personaje de la biblioteca compartida */}
      {pickingExtra && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 p-4 sm:items-center" onClick={() => setPicking(null)}>
          <div className="max-h-[80vh] w-full max-w-md overflow-y-auto rounded-2xl border border-amber-400/25 bg-[#161126] p-3 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-2 flex items-center gap-2">
              <Users size={15} className="text-amber-300" />
              <p className="min-w-0 flex-1 truncate text-[13px] font-bold text-white">Quién es «{pickingExtra.name}»</p>
              <button onClick={() => setPicking(null)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/60 active:bg-white/10" aria-label="Cerrar">
                <X size={16} />
              </button>
            </div>
            <p className="mb-2 text-[11px] leading-snug text-white/45">
              Sale de tu biblioteca compartida, la misma que usan BF, GF y DAD. Si te falta alguno, impórtalo antes en un puesto normal y
              aquí lo podrás elegir.
            </p>
            {charLib.length ? (
              <div className="grid grid-cols-3 gap-2">
                {charLib.map((e) => (
                  <button
                    key={e.id}
                    onClick={() => assign(pickingExtra, e)}
                    className="flex flex-col items-center rounded-xl border border-white/10 bg-white/[0.03] p-2 text-center transition hover:-translate-y-px hover:border-amber-400/50 active:scale-95"
                  >
                    <span className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-lg bg-[#0b0916]">
                      {e.iconData || e.thumb ? (
                        <img src={(e.iconData ?? e.thumb)!} alt="" className="h-full w-full object-cover" draggable={false} />
                      ) : (
                        <UserRound size={18} className="text-white/30" />
                      )}
                    </span>
                    <span className="mt-1 line-clamp-2 w-full text-[10px] font-semibold leading-tight text-white/85">{e.name}</span>
                    <span className="text-[9px] text-white/35">{e.char.animations.length} anims</span>
                  </button>
                ))}
              </div>
            ) : (
              <p className="rounded-xl bg-white/[0.04] p-4 text-center text-[11px] leading-snug text-white/40">
                Tu biblioteca está vacía. Importa un personaje desde un puesto (BF / GF / DAD) y aquí lo podrás elegir.
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
