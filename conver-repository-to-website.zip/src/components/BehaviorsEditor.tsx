import { useEffect, useState } from 'react';
import { Loader2, Plus, Sparkles, Trash2 } from 'lucide-react';
import { useEditor } from '../store';
import type { Behavior, BehaviorType, BumpProp, Layer } from '../types';
import { BEHAVIOR_INFO, CHAR_INFO, CHAR_KEYS, newBehavior } from '../lib/defaults';
import { Btn, Field, NumberInput, Segmented, Select, SliderRow, TextInput, Toggle } from './ui';
import { parseColors } from '../lib/behaviors';
import { ensureLitChars } from '../lib/charlib';
import RainPreview from './RainPreview';
import { checkFrag } from '../lib/customFrag';
import { cn } from '../utils/cn';

/** Mecánicas de los escenarios oficiales listas para usar en cualquier capa */
const MECH_PRESETS: { label: string; desc: string; type: BehaviorType; values: Partial<Behavior> }[] = [
  {
    label: 'Tren de Philly (week 3)',
    desc: '30% en el beat 4 de cada 8, audio 4.7 s antes de moverse, 8 vagones y GF se despeina.',
    type: 'passBy',
    values: { every: 8, phase: 4, chance: 30, cooldown: 8, speed: 9600, startX: 2000, endX: -2000, loopX: -1150, finishX: -4000, repeats: 8, delay: 4.7, sound: 'train_passes', gfHair: true },
  },
  {
    label: 'Coche de Limo (week 4)',
    desc: 'Cruza a toda velocidad de izquierda a derecha (10% por beat).',
    type: 'passBy',
    values: { startX: -12600, finishX: 3000, speed: 35000, repeats: 0, chance: 10, every: 1, phase: 0, cooldown: 0, gfHair: false, delay: 0, sound: '', randomAnim: false },
  },
  { label: 'Ventanas de Philly (week 3)', desc: 'Color al azar cada 4 beats que se va apagando.', type: 'lightCycle', values: { every: 4 } },
  { label: 'Tanque rodando (week 7)', desc: 'Vuelta en elipse por detrás del escenario.', type: 'orbit', values: {} },
  { label: 'Nubes (week 7)', desc: 'Se desplazan despacio y sin parar.', type: 'scroll', values: { speed: 10, range: 0 } },
  { label: 'Rayo de Spooky (week 2)', desc: 'Animación del rayo + trueno + destello + zoom + sustos.', type: 'lightning', values: { sound: 'thunder' } },
  {
    label: 'Rayo de Spooky Mansion Erect (week 2)',
    desc: 'Enciende esta capa, destello blanco, trueno, zoom 0.015, sustos e ilumina a los personajes 1.5 s (gemelo si son -dark, tinte si no).',
    type: 'lightning',
    values: { anim: '', group: 'trueno', chance: 10, minGap: 8, maxGap: 24, flash: true, zoomBump: 0.015, scare: true, sound: 'thunder', litChars: true },
  },
  { label: 'Bop en cada beat (week 5 / 7)', desc: 'El público / los tanques bailan en cada beat.', type: 'beatAnim', values: { every: 1 } },
  {
    label: 'Lluvia de P-Slice (Spooky Mansion Erect)',
    desc: 'RainShader sobre la capa: 4 profundidades de gotas que refractan el dibujo y lo tiñen de azul.',
    type: 'rain',
    values: { rainScale: 7.2, rainIntensity: 0.4 },
  },
];

export default function BehaviorsEditor({ layer }: { layer: Layer }) {
  const commit = useEditor((s) => s.commit);
  const playing = useEditor((s) => s.playing);
  const toast = useEditor((s) => s.toast);
  const characters = useEditor((s) => s.project.characters);
  const [adding, setAdding] = useState(false);
  const [litBusy, setLitBusy] = useState(false);
  const animated = layer.kind === 'animated';
  const animOpts = layer.animations.map((a) => ({ value: a.anim, label: a.anim }));

  /** Descarga el "fantasma" iluminado de cada puesto (Spooky Mansion Erect de P-Slice) */
  const loadGhosts = async () => {
    if (litBusy) return;
    setLitBusy(true);
    try {
      const { ok, notes } = await ensureLitChars();
      if (!notes.length) toast('Pon personajes en GF, DAD y BF para poder iluminarlos.', 'err');
      else toast(notes.join(' · '), ok ? undefined : 'err');
    } catch (e) {
      toast('No se pudieron cargar: ' + ((e as Error)?.message || 'sin conexión'), 'err');
    } finally {
      setLitBusy(false);
    }
  };

  const mut = (fn: (l: Layer) => void, key?: string) =>
    commit((d) => {
      const l = d.layers.find((x) => x.id === layer.id);
      if (l) fn(l);
    }, key);
  const upd = (id: string, patch: Partial<Behavior>) =>
    mut((l) => {
      const b = l.behaviors.find((x) => x.id === id);
      if (b) Object.assign(b, patch);
    }, 'beh:' + id + ':' + Object.keys(patch).join());

  const add = (type: BehaviorType, extra: Partial<Behavior> = {}) => {
    const first = layer.animations[0] ? layer.animations[0].anim : '';
    const has = (n: string) => layer.animations.some((a) => a.anim === n);
    const b = newBehavior(type, { ...(type === 'beatAnim' || type === 'lightning' ? { anim: first } : {}), ...extra });
    // si el preset ya trae animación (o la deja vacía a propósito, como las luces de
    // Spooky Mansion Erect) no se sobreescribe con la primera de la capa
    if (type === 'lightning' && !('anim' in extra)) b.anim = layer.animations.find((a) => /strike|lightning|rayo/i.test(a.anim + a.prefix))?.anim ?? first;
    if (type === 'danceLR') {
      b.anim = has('danceLeft') ? 'danceLeft' : first;
      b.anim2 = has('danceRight') ? 'danceRight' : layer.animations[1] ? layer.animations[1].anim : first;
    }
    mut((l) => l.behaviors.push(b));
    setAdding(false);
    // al poner personajes iluminados ya se descargan sus fantasmas (vale para cualquier puesto)
    if (b.litChars) void loadGhosts();
  };

  const types = (Object.keys(BEHAVIOR_INFO) as BehaviorType[]).filter((t) => animated || !BEHAVIOR_INFO[t].animOnly);

  return (
    <div className="space-y-3">
      <p className="text-[11px] leading-snug text-white/40">
        Efectos que se exportan al .lua y se ven en la vista previa {playing ? '(reproduciendo ahora)' : '(pulsa ▶ arriba)'}. Se pueden combinar varios.
      </p>
      {layer.behaviors.map((b) => (
        <div key={b.id} className={cn('rounded-xl border bg-black/20 p-3', b.enabled ? 'border-emerald-400/25' : 'border-white/10 opacity-60')}>
          <div className="mb-2 flex items-center gap-2">
            <button
              onClick={() => upd(b.id, { enabled: !b.enabled })}
              className={cn('h-5 w-5 shrink-0 rounded-md border', b.enabled ? 'border-emerald-300 bg-emerald-400' : 'border-white/30')}
              title="Activar / desactivar"
            />
            <span className="text-[13px] font-semibold text-white">{BEHAVIOR_INFO[b.type].label}</span>
            <button className="ml-auto flex h-8 w-8 items-center justify-center rounded-lg text-rose-300 active:bg-rose-500/20" onClick={() => mut((l) => (l.behaviors = l.behaviors.filter((x) => x.id !== b.id)))}>
              <Trash2 size={15} />
            </button>
          </div>
          <div className="space-y-2">
            {b.type === 'beatAnim' && (
              <div className="grid grid-cols-2 gap-2">
                <Field label="Animación">
                  {animOpts.length ? <Select value={b.anim} options={animOpts} onChange={(v) => upd(b.id, { anim: v })} /> : <span className="text-[12px] text-rose-300">Sin animaciones</span>}
                </Field>
                <Field label="Cada N beats">
                  <NumberInput value={b.every} onChange={(v) => upd(b.id, { every: v })} min={1} max={64} precision={0} />
                </Field>
              </div>
            )}
            {b.type === 'danceLR' && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Izquierda">
                    <Select value={b.anim} options={animOpts} onChange={(v) => upd(b.id, { anim: v })} />
                  </Field>
                  <Field label="Derecha">
                    <Select value={b.anim2} options={animOpts} onChange={(v) => upd(b.id, { anim2: v })} />
                  </Field>
                </div>
                <Field label="Cada N beats">
                  <NumberInput value={b.every} onChange={(v) => upd(b.id, { every: v })} min={1} max={64} precision={0} />
                </Field>
              </>
            )}
            {b.type === 'float' && (
              <>
                <Segmented value={b.axis} options={[{ value: 'y', label: 'Vertical (Y)' }, { value: 'x', label: 'Horizontal (X)' }]} onChange={(v) => upd(b.id, { axis: v })} />
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Distancia (px)">
                    <NumberInput value={b.amount} onChange={(v) => upd(b.id, { amount: v })} step={1} precision={1} />
                  </Field>
                  <Field label="Periodo (seg)">
                    <NumberInput value={b.period} onChange={(v) => upd(b.id, { period: v })} step={0.1} min={0.05} precision={2} />
                  </Field>
                </div>
                <Field label="Desfase (0-1)" hint="Útil para que varias capas no floten al mismo tiempo.">
                  <NumberInput value={b.phase} onChange={(v) => upd(b.id, { phase: v })} step={0.05} min={0} max={1} precision={2} />
                </Field>
              </>
            )}
            {b.type === 'spin' && (
              <Field label="Velocidad (grados/seg)" hint="Negativo = sentido antihorario.">
                <NumberInput value={b.speed} onChange={(v) => upd(b.id, { speed: v })} step={5} precision={1} />
              </Field>
            )}
            {b.type === 'scroll' && <ScrollSpeed b={b} upd={upd} />}
            {b.type === 'beatBump' && (
              <>
                <Segmented
                  value={b.prop}
                  options={[
                    { value: 'scale', label: 'Escala' },
                    { value: 'alpha', label: 'Brillo' },
                    { value: 'y', label: 'Salto' },
                    { value: 'angle', label: 'Giro' },
                  ]}
                  onChange={(v: BumpProp) => upd(b.id, { prop: v, amount: v === 'scale' ? 0.06 : v === 'alpha' ? 0.5 : v === 'y' ? 25 : 8 })}
                />
                <div className="grid grid-cols-3 gap-2">
                  <Field label={b.prop === 'scale' ? 'Fuerza (x)' : b.prop === 'alpha' ? 'Alpha +' : b.prop === 'y' ? 'Px' : 'Grados'}>
                    <NumberInput value={b.amount} onChange={(v) => upd(b.id, { amount: v })} step={b.prop === 'scale' || b.prop === 'alpha' ? 0.01 : 1} precision={3} />
                  </Field>
                  <Field label="Cada N">
                    <NumberInput value={b.every} onChange={(v) => upd(b.id, { every: v })} min={1} max={64} precision={0} />
                  </Field>
                  <Field label="Caída">
                    <NumberInput value={b.decay} onChange={(v) => upd(b.id, { decay: v })} step={0.5} min={0.1} precision={1} />
                  </Field>
                </div>
              </>
            )}
            {b.type === 'lightCycle' && (
              <>
                <Field label="Colores (hex, separados por coma)" hint="Ventanas de Philly: 31A2FD, 31FD8C, FB33F5, FD4531, FBA633">
                  <TextInput value={b.colors} onCommit={(v) => upd(b.id, { colors: v })} mono />
                </Field>
                <div className="flex flex-wrap gap-1">
                  {parseColors(b.colors).map((c, i) => (
                    <span key={i} className="h-5 w-8 rounded border border-white/20" style={{ background: '#' + c }} />
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Cada N beats">
                    <NumberInput value={b.every} onChange={(v) => upd(b.id, { every: v })} min={1} max={64} precision={0} />
                  </Field>
                  <Field label="Velocidad de apagado">
                    <NumberInput value={b.amount} onChange={(v) => upd(b.id, { amount: v })} step={0.1} min={0.05} precision={2} />
                  </Field>
                </div>
              </>
            )}
            {b.type === 'passBy' && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="X inicio (fuera de pantalla)">
                    <NumberInput value={b.startX} onChange={(v) => upd(b.id, { startX: v })} step={50} precision={0} />
                  </Field>
                  <Field label="X final">
                    <NumberInput value={b.finishX} onChange={(v) => upd(b.id, { finishX: v })} step={50} precision={0} />
                  </Field>
                  <Field label="Velocidad (px/s)">
                    <NumberInput value={b.speed} onChange={(v) => upd(b.id, { speed: v })} step={100} precision={0} />
                  </Field>
                  <Field label="Repeticiones (vagones)" hint="0 = pasa una vez">
                    <NumberInput value={b.repeats} onChange={(v) => upd(b.id, { repeats: Math.max(0, v) })} min={0} max={50} precision={0} />
                  </Field>
                </div>
                {b.repeats > 0 && (
                  <div className="grid grid-cols-2 gap-2">
                    <Field label="Vuelve a X" hint="al repetir">
                      <NumberInput value={b.loopX} onChange={(v) => upd(b.id, { loopX: v })} step={50} precision={0} />
                    </Field>
                    <Field label="Repite al pasar X">
                      <NumberInput value={b.endX} onChange={(v) => upd(b.id, { endX: v })} step={50} precision={0} />
                    </Field>
                  </div>
                )}
                <div className="grid grid-cols-3 gap-2">
                  <Field label="Probab. %">
                    <NumberInput value={b.chance} onChange={(v) => upd(b.id, { chance: v })} min={0} max={100} precision={0} />
                  </Field>
                  <Field label="Cada N beats">
                    <NumberInput value={b.every} onChange={(v) => upd(b.id, { every: v })} min={1} max={64} precision={0} />
                  </Field>
                  <Field label="En el beat">
                    <NumberInput value={b.phase} onChange={(v) => upd(b.id, { phase: v })} min={0} max={63} precision={0} />
                  </Field>
                </div>
                <Field label="Espera mínima (beats)">
                  <NumberInput value={b.cooldown} onChange={(v) => upd(b.id, { cooldown: v })} min={0} max={64} precision={0} />
                </Field>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Retraso antes de moverse (s)" hint="El tren de Philly reproduce 4.7 s de audio antes de entrar.">
                    <NumberInput value={b.delay} onChange={(v) => upd(b.id, { delay: Math.max(0, v) })} step={0.1} min={0} precision={2} />
                  </Field>
                  <Field label="Sonido (sin extensión)" hint="Vacío = sin audio">
                    <TextInput value={b.sound} onCommit={(v) => upd(b.id, { sound: v.trim() })} mono placeholder="train_passes" />
                  </Field>
                </div>
                {layer.kind === 'animated' && (
                  <Toggle checked={b.randomAnim} onChange={(v) => upd(b.id, { randomAnim: v })} label="Elegir car1 / car2… al azar" hint="Para sprites con animaciones numeradas." />
                )}
                <Toggle checked={b.gfHair} onChange={(v) => upd(b.id, { gfHair: v })} label="GF se despeina (hairBlow / hairFall)" hint="Opcional. Empieza cuando el tren se mueve y vuelve al terminar." />
              </>
            )}
            {b.type === 'orbit' && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Centro X">
                    <NumberInput value={b.centerX} onChange={(v) => upd(b.id, { centerX: v })} step={10} precision={0} />
                  </Field>
                  <Field label="Centro Y">
                    <NumberInput value={b.centerY} onChange={(v) => upd(b.id, { centerY: v })} step={10} precision={0} />
                  </Field>
                  <Field label="Radio X">
                    <NumberInput value={b.radiusX} onChange={(v) => upd(b.id, { radiusX: v })} step={10} precision={0} />
                  </Field>
                  <Field label="Radio Y">
                    <NumberInput value={b.radiusY} onChange={(v) => upd(b.id, { radiusY: v })} step={10} precision={0} />
                  </Field>
                  <Field label="Velocidad (grados/s)">
                    <NumberInput value={b.speed} onChange={(v) => upd(b.id, { speed: v })} step={0.5} precision={2} />
                  </Field>
                  <Field label="Ángulo inicial">
                    <NumberInput value={b.phase} onChange={(v) => upd(b.id, { phase: v })} step={5} precision={1} />
                  </Field>
                </div>
                <Toggle checked={b.rotate} onChange={(v) => upd(b.id, { rotate: v })} label="Girar siguiendo el camino" />
                {b.rotate && (
                  <Field label="Ajuste de giro (grados)">
                    <NumberInput value={b.angleOffset} onChange={(v) => upd(b.id, { angleOffset: v })} step={5} precision={1} />
                  </Field>
                )}
              </>
            )}
            {b.type === 'lightning' && (
              <>
                <Field label="Al caer el rayo" hint="Sin animación: la capa se enciende (alpha 1) y se apaga en 1.5 s.">
                  <Select value={b.anim} options={[{ value: '', label: '— encender la capa —' }, ...animOpts]} onChange={(v) => upd(b.id, { anim: v })} />
                </Field>
                <Field label="Grupo (opcional)" hint="Las capas con el mismo grupo caen a la vez (ej: luz del fondo + luz de la escalera).">
                  <TextInput value={b.group} onCommit={(v) => upd(b.id, { group: v.trim() })} placeholder="ej: trueno" mono />
                </Field>
                <div className="grid grid-cols-3 gap-2">
                  <Field label="Probab. %">
                    <NumberInput value={b.chance} onChange={(v) => upd(b.id, { chance: v })} min={0} max={100} precision={0} />
                  </Field>
                  <Field label="Espera mín.">
                    <NumberInput value={b.minGap} onChange={(v) => upd(b.id, { minGap: v })} min={0} max={128} precision={0} />
                  </Field>
                  <Field label="Espera máx.">
                    <NumberInput value={b.maxGap} onChange={(v) => upd(b.id, { maxGap: v })} min={0} max={128} precision={0} />
                  </Field>
                </div>
                <Toggle checked={b.flash} onChange={(v) => upd(b.id, { flash: v })} label="Destello blanco" />
                <Field label="Zoom de cámara al caer">
                  <NumberInput value={b.zoomBump} onChange={(v) => upd(b.id, { zoomBump: v })} step={0.005} min={0} precision={3} />
                </Field>
                <Toggle checked={b.scare} onChange={(v) => upd(b.id, { scare: v })} label="Los personajes se asustan" hint="Animación 'scared' (si el personaje la tiene)." />
                <Field label="Sonido del trueno" hint="Prefijo en sounds/: se elige _1 o _2 al azar (thunder → thunder_1 / thunder_2). Vacío = sin sonido.">
                  <TextInput value={b.sound} onCommit={(v) => upd(b.id, { sound: v.trim() })} placeholder="thunder" mono />
                </Field>
                <Toggle
                  checked={b.litChars}
                  onChange={(v) => {
                    upd(b.id, { litChars: v });
                    if (v) void loadGhosts();
                  }}
                  label="Personajes iluminados (Spooky Mansion Erect)"
                  hint="Con el rayo el personaje se ilumina y vuelve a oscurarse en 1.5 s. Si tiene variante -dark aparece su gemelo claro debajo; si no, se tiñe de #070711 y relumbra en blanco. Funciona con cualquier personaje."
                />
                {b.litChars && (
                  <div className="space-y-1 rounded-xl bg-black/25 p-2.5">
                    {CHAR_KEYS.map((k) => {
                      const c = characters[k];
                      const name = c.custom?.fileName ?? '';
                      const dark = /-dark$/i.test(name);
                      const lit = c.lit;
                      return (
                        <div key={k} className="flex items-center gap-1.5 text-[11px] leading-snug">
                          <span className="w-7 shrink-0 font-black" style={{ color: CHAR_INFO[k].color }}>
                            {CHAR_INFO[k].short}
                          </span>
                          <span className={cn('min-w-0 flex-1 truncate font-mono', name ? 'text-white/70' : 'text-white/30')}>{name || 'sin personaje'}</span>
                          {!name ? null : dark ? (
                            <span
                              className={cn(
                                'shrink-0 rounded-md px-1.5 py-0.5 font-mono text-[9px] font-bold uppercase tracking-wide',
                                lit ? 'bg-fuchsia-500/25 text-fuchsia-200' : 'bg-amber-500/20 text-amber-200/80',
                              )}
                            >
                              {lit ? 'gemelo ' + lit.fileName : litBusy ? 'cargando…' : 'sin gemelo'}
                            </span>
                          ) : (
                            <span className="shrink-0 rounded-md bg-cyan-500/20 px-1.5 py-0.5 font-mono text-[9px] font-bold uppercase tracking-wide text-cyan-200">
                              tinte #070711
                            </span>
                          )}
                        </div>
                      );
                    })}
                    <button
                      type="button"
                      disabled={litBusy}
                      onClick={() => void loadGhosts()}
                      className="mt-0.5 flex w-full items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-2 py-1.5 text-[11px] font-semibold text-white/80 transition active:scale-[0.98] disabled:opacity-50"
                    >
                      {litBusy ? <Loader2 size={12} className="animate-spin text-fuchsia-300" /> : <Sparkles size={12} className="text-fuchsia-300" />}
                      {litBusy ? 'Descargando…' : 'Recargar gemelos iluminados'}
                    </button>
                    <p className="text-[10px] leading-snug text-white/30">
                      Solo los <span className="font-mono text-white/45">-dark</span> necesitan gemelo; el resto se resuelve con el tinte, sin descargar nada.
                    </p>
                  </div>
                )}
              </>
            )}
            {b.type === 'fade' && (
              <>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Alpha mínimo">
                    <NumberInput value={b.min} onChange={(v) => upd(b.id, { min: v })} step={0.05} min={0} max={1} precision={2} />
                  </Field>
                  <Field label="Alpha máximo">
                    <NumberInput value={b.max} onChange={(v) => upd(b.id, { max: v })} step={0.05} min={0} max={1} precision={2} />
                  </Field>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Field label="Periodo (seg)">
                    <NumberInput value={b.period} onChange={(v) => upd(b.id, { period: v })} step={0.1} min={0.05} precision={2} />
                  </Field>
                  <Field label="Desfase (0-1)">
                    <NumberInput value={b.phase} onChange={(v) => upd(b.id, { phase: v })} step={0.05} min={0} max={1} precision={2} />
                  </Field>
                </div>
              </>
            )}
            {b.type === 'rain' && (
              <div className="space-y-2.5">
                <RainPreview scale={b.rainScale} intensity={b.rainIntensity} />
                <SliderRow label="Intensidad" value={b.rainIntensity} onChange={(v) => upd(b.id, { rainIntensity: v })} min={0} max={1} step={0.01} />
                <SliderRow label="Escala de la gota" value={b.rainScale} onChange={(v) => upd(b.id, { rainScale: v })} min={1} max={20} step={0.1} precision={1} />
                <p className="text-[11px] leading-snug text-white/40">
                  P-Slice usa <span className="font-mono text-cyan-200/80">scale = FlxG.height / 200 * 2</span> (7.2 a 720p) y{' '}
                  <span className="font-mono text-cyan-200/80">intensity = 0.4</span> sobre los árboles. La vista previa resuelve{' '}
                  <span className="font-mono text-white/60">rainDist()</span> del .frag capa a capa: cizalla, refracción, luz y el tinte{' '}
                  <span className="font-mono text-[#8fa4e8]">#6680cc</span>.
                </p>
              </div>
            )}
            {b.type === 'custom' && <CustomBehavior b={b} layerName={layer.name} onChange={(p: Partial<Behavior>) => upd(b.id, p)} />}
            {b.type === 'frag' && <FragBehavior b={b} onChange={(p: Partial<Behavior>) => upd(b.id, p)} />}
          </div>
        </div>
      ))}
      {adding ? (
        <div className="space-y-1.5 rounded-xl border border-violet-400/30 bg-violet-500/5 p-2">
          {types.map((t) => (
            <button key={t} onClick={() => add(t)} className="block w-full rounded-lg px-3 py-2 text-left active:bg-white/10">
              <span className="block text-[13px] font-semibold text-white">{BEHAVIOR_INFO[t].label}</span>
              <span className="block text-[11px] text-white/45">{BEHAVIOR_INFO[t].desc}</span>
            </button>
          ))}
          <p className="px-3 pt-2 text-[10px] font-bold uppercase tracking-widest text-violet-200/60">Como en los escenarios de FNF</p>
          {MECH_PRESETS.filter((m) => animated || !BEHAVIOR_INFO[m.type].animOnly).map((m) => (
            <button key={m.label} onClick={() => add(m.type, m.values)} className="block w-full rounded-lg px-3 py-2 text-left active:bg-white/10">
              <span className="block text-[13px] font-semibold text-fuchsia-100">{m.label}</span>
              <span className="block text-[11px] text-white/45">{m.desc}</span>
            </button>
          ))}
          <Btn className="w-full" onClick={() => setAdding(false)}>
            Cancelar
          </Btn>
        </div>
      ) : (
        <Btn variant="soft" className="w-full" onClick={() => setAdding(true)}>
          <Plus size={15} /> Añadir comportamiento
        </Btn>
      )}
      {!animated && (
        <p className="text-[11px] leading-snug text-white/35">
          "Animación en beat" y "Baile izq/der" aparecen cuando la capa es un sprite animado (imagen + .xml).
        </p>
      )}
    </div>
  );
}

/* ---------- «Desplazar en bucle»: aquí mismo se elige a qué velocidad se desliza ---------- */

/** Velocidades de referencia, de un fondo casi quieto a un primer plano a toda leche */
const SCROLL_SPEED_STEPS = [
  { l: 'Alto', v: 0 },
  { l: 'Muy lento', v: 5 },
  { l: 'Lento', v: 25 },
  { l: 'Medio', v: 60 },
  { l: 'Rápido', v: 160 },
  { l: 'Frenético', v: 450 },
];

const spdTxt = (v: number) => String(Math.round(v * 100) / 100);
const spdDur = (s: number) => {
  if (!isFinite(s) || s <= 0) return '—';
  if (s < 10) return s.toFixed(1) + ' s';
  if (s < 60) return Math.round(s) + ' s';
  const m = Math.floor(s / 60);
  return m + ' m ' + String(Math.round(s - m * 60)).padStart(2, '0') + ' s';
};

/**
 * Trabaja sobre los speed / speedY / range de siempre: no cambia el modelo, la
 * simulación de behaviors.ts ni el .lua que se exporta. Todo se calcula al pintar,
 * sin bucles de animación propios que estorben a la vista previa.
 */
function ScrollSpeed({ b, upd }: { b: Behavior; upd: (id: string, patch: Partial<Behavior>) => void }) {
  const mag = Math.hypot(b.speed, b.speedY);
  const quiet = mag < 0.01;

  /** Sube o baja la velocidad conservando la dirección actual, diagonales a medida incluidas */
  const setMag = (m: number) => {
    const v = Math.max(0, m);
    const k = v / (quiet ? 1 : mag);
    upd(b.id, quiet ? { speed: Math.round(v * 100) / 100, speedY: 0 } : { speed: Math.round(b.speed * k * 100) / 100, speedY: Math.round(b.speedY * k * 100) / 100 });
  };

  const loop = b.range > 0 && !quiet ? b.range / mag : null;

  return (
    <>
      <div className="rounded-xl border border-violet-400/20 bg-violet-500/[0.07] px-3 py-2">
        <div className="flex items-baseline gap-1.5">
          <span className="font-mono text-[21px] font-bold leading-none tracking-tight text-white">{spdTxt(mag)}</span>
          <span className="text-[11px] font-semibold uppercase tracking-wider text-violet-200/70">px / segundo</span>
        </div>
        <p className="mt-1 text-[11px] leading-snug text-white/45">
          {quiet
            ? 'Esta capa no se desliza todavía: mueve la barra o toca una velocidad.'
            : loop
              ? `Se desliza ${spdTxt(mag)} px cada segundo y vuelve al inicio cada ${spdDur(loop)}.`
              : `Se desliza ${spdTxt(mag)} px cada segundo y no vuelve (distancia del bucle a 0).`}
        </p>
      </div>

      <SliderRow label="Velocidad (px/s)" value={Math.round(mag * 100) / 100} onChange={setMag} min={0} max={600} step={1} precision={2} />

      <div>
        <span className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-violet-200/60">Velocidades listas</span>
        <div className="flex flex-wrap gap-1">
          {SCROLL_SPEED_STEPS.map((p) => (
            <button
              key={p.l}
              type="button"
              onClick={() => setMag(p.v)}
              className={cn(
                'rounded-lg border px-2 py-1 text-[11px] font-semibold transition active:scale-95',
                Math.abs(mag - p.v) < 0.5
                  ? 'border-fuchsia-400/60 bg-fuchsia-500/20 text-fuchsia-100'
                  : 'border-white/10 bg-white/[0.04] text-white/55 hover:border-violet-400/40 hover:text-white/90',
              )}
            >
              {p.l}
              <span className="ml-1 font-mono text-[10px] opacity-60">{p.v}</span>
            </button>
          ))}
        </div>
        <p className="mt-1.5 text-[11px] leading-snug text-white/40">
          Mantienen la dirección y solo cambian cuántos píxeles se desliza por segundo.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Field label="Vel. X (px/s)">
          <NumberInput value={b.speed} onChange={(v) => upd(b.id, { speed: v })} step={5} precision={1} />
        </Field>
        <Field label="Vel. Y (px/s)">
          <NumberInput value={b.speedY} onChange={(v) => upd(b.id, { speedY: v })} step={5} precision={1} />
        </Field>
      </div>
      <p className="-mt-1 text-[11px] leading-snug text-white/40">
        Aquí va la velocidad exacta por eje, sin límite: se puede arrastrar, escribir o dejarla fuera del rango de la barra. X
        negativo desliza hacia la izquierda y Y negativo hacia arriba; combinando los dos sale cualquier diagonal.
      </p>

      <Field label="Distancia del bucle (px)" hint="Al recorrer esta distancia vuelve al inicio. 0 = se aleja para siempre.">
        <NumberInput value={b.range} onChange={(v) => upd(b.id, { range: v })} step={50} min={0} precision={0} />
      </Field>
    </>
  );
}

/* ---------- «Comportamiento propio»: el Lua de la persona, inyectado tal cual al exportar ---------- */

/** Trozos listos para no empezar desde cero; se añaden al final del código */
const LUA_SNIPPETS: { l: string; code: string }[] = [
  { l: 'Ocultar', code: "setProperty(TAG .. '.visible', false)" },
  { l: 'Fundido', code: "doTweenAlpha(TAG .. '_tw', TAG, 0.35, 0.6, 'quadOut')" },
  { l: 'Tinte', code: "setProperty(TAG .. '.color', getColorFromHex('FF3355'))" },
  { l: 'Sacudida', code: "setProperty(TAG .. '.x', getProperty(TAG .. '.x') + getRandomInt(-6, 6))" },
  { l: 'Animación', code: "playAnim(TAG, 'idle', true)" },
  { l: 'Sonido', code: "playSound('train_passes', 1)" },
  { l: 'Zoom', code: "setProperty('camGame.zoom', getProperty('camGame.zoom') + 0.02)" },
  { l: 'Escala', code: "setProperty(TAG .. '.scale.x', 1.05)\nsetProperty(TAG .. '.scale.y', 1.05)" },
  { l: 'Bop en beat', code: "if beatJustHit then\n  setProperty(TAG .. '.scale.x', 1.06)\n  setProperty(TAG .. '.scale.y', 1.06)\nend" },
];

/** Ejemplos completos y probados: sustituyen todo el código para estudiarlos y adaptarlos */
const LUA_EXAMPLES: { l: string; code: string }[] = [
  {
    l: 'Círculo (orbital)',
    code: `-- Gira alrededor de su posicion original (movimiento orbital).
local radio = 80
local velocidad = 2
local cx = getProperty(TAG .. '.x')
local cy = getProperty(TAG .. '.y')
local tiempo = 0

function onUpdate(elapsed)
  tiempo = tiempo + elapsed * velocidad
  setProperty(TAG .. '.x', cx + math.cos(tiempo) * radio)
  setProperty(TAG .. '.y', cy + math.sin(tiempo) * radio)
end`,
  },
  {
    l: 'Girar y flotar',
    code: `-- Gira despacio y flota arriba y abajo.
local giro = 40
local flote = 12

function onUpdate(elapsed)
  setProperty(TAG .. '.angle', t * giro)
  setProperty(TAG .. '.y', getProperty(TAG .. '.y') + math.sin(t * 2.2) * flote)
end`,
  },
  {
    l: 'Bop en cada beat',
    code: `-- Un golpe de escala en cada beat, como el publico de la week 5.
function onBeatHit()
  setProperty(TAG .. '.scale.x', 1.08)
  setProperty(TAG .. '.scale.y', 1.08)
end`,
  },
  {
    l: 'Parpadeo',
    code: `-- El alpha oscila entre 0.2 y 1, como una luz que parpadea.
function onUpdate(elapsed)
  setProperty(TAG .. '.alpha', 0.6 + math.sin(t * 4) * 0.4)
end`,
  },
];

function CustomBehavior({ b, layerName, onChange }: { b: Behavior; layerName: string; onChange: (patch: Partial<Behavior>) => void }) {
  const [showOut, setShowOut] = useState(false);
  const code = b.code ?? '';
  const lines = code
    .split(/\r?\n/)
    .map((l) => l.replace(/\s+$/, ''))
    .filter((l) => l.trim().length > 0);

  const append = (s: string) => onChange({ code: (code.trim() ? code.replace(/\s+$/, '') + '\n' : '') + s + '\n' });

  /** Tal cual saldrá en el .lua, dentro de onUpdate */
  const out = [
    `-- comportamiento propio de ${layerName} · va en onUpdate(elapsed)`,
    'do',
    '\tlocal beatJustHit = curBeat ~= __ultimoBeat',
    '\t__ultimoBeat = curBeat',
    `\tlocal TAG = P .. '${layerName}'`,
    ...lines.map((l) => '\t' + l),
    'end',
  ].join('\n');

  return (
    <>
      <p className="text-[11px] leading-snug text-white/40">
        Se inyecta en <b className="text-white/60">onUpdate(elapsed)</b> del .lua exportado —el sitio más general—, donde ya
        tienes <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">elapsed</code>,{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">t</code> (segundos desde el inicio),{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">curBeat</code>,{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">curStep</code> y{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">crochet</code>. Y{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">beatJustHit</code> vale true solo en el
        primer frame de cada beat: lo que quieras hacer «en cada beat» va dentro de un{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">if beatJustHit then</code>.
      </p>
      <p className="-mt-1 rounded-lg bg-emerald-500/[0.07] px-2 py-1.5 text-[11px] leading-snug text-emerald-100/70">
        La vista previa <b>ejecuta tu Lua de Psych de verdad</b> al darle a ▶: variables <span className="font-mono text-[10px]">local</span> con
        estado entre frames, <span className="font-mono text-[10px]">function onCreate/onUpdate/onBeatHit</span>,{' '}
        <span className="font-mono text-[10px]">if/elseif/else</span>, <span className="font-mono text-[10px]">for</span>,{' '}
        <span className="font-mono text-[10px]">math.*</span> y <span className="font-mono text-[10px]">setProperty/getProperty</span> con el nombre
        del objeto o con <span className="font-mono text-[10px]">TAG</span>. Lo que exige el juego completo (sonidos, Haxe, shaders) corre igual al
        exportar.
      </p>
      <Field label="Código Lua de este comportamiento">
        <textarea
          value={code}
          spellCheck={false}
          rows={Math.min(16, Math.max(6, lines.length + 2))}
          placeholder={"setProperty(TAG .. '.alpha', 0.5)\ndoTweenAngle(TAG .. '_spin', TAG, 360, 1.2, 'linear')"}
          onChange={(e) => onChange({ code: e.target.value })}
          onKeyDown={(e) => {
            // Tab mete dos espacios en vez de sacar el foco del editor
            if (e.key !== 'Tab') return;
            e.preventDefault();
            const el = e.currentTarget;
            const a = el.selectionStart;
            const z = el.selectionEnd;
            const next = code.slice(0, a) + '  ' + code.slice(z);
            onChange({ code: next });
            requestAnimationFrame(() => {
              el.selectionStart = el.selectionEnd = a + 2;
            });
          }}
          className="w-full resize-y overflow-x-auto whitespace-pre rounded-xl border border-white/10 border-l-2 border-l-violet-400/60 bg-[#0b0818] px-3 py-2.5 font-mono text-[12px] leading-relaxed text-emerald-100/90 outline-none placeholder:text-white/20 focus:border-violet-400/60 focus:border-l-violet-300"
        />
      </Field>

      <div>
        <span className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-violet-200/60">Ejemplos completos (sustituyen el código)</span>
        <div className="flex flex-wrap gap-1">
          {LUA_EXAMPLES.map((x) => (
            <button
              key={x.l}
              type="button"
              onClick={() => onChange({ code: x.code + '\n' })}
              className="rounded-lg border border-violet-400/35 bg-violet-500/10 px-2 py-1 text-[11px] font-semibold text-violet-100 transition hover:bg-violet-500/20 active:scale-95"
            >
              {x.l}
            </button>
          ))}
        </div>
        <p className="mt-1 text-[10px] leading-snug text-white/35">
          Cargan un ejemplo que funciona de verdad: míralo con ▶ y luego adáptalo a tu capa.
        </p>
      </div>

      <div>
        <span className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-violet-200/60">Trozos listos (se añaden al final)</span>
        <div className="flex flex-wrap gap-1">
          {LUA_SNIPPETS.map((s) => (
            <button
              key={s.l}
              type="button"
              onClick={() => append(s.code)}
              className="rounded-lg border border-white/10 bg-white/[0.04] px-2 py-1 font-mono text-[10px] font-semibold text-white/60 transition active:scale-95 hover:border-violet-400/45 hover:text-white/90"
            >
              {s.l}
            </button>
          ))}
        </div>
      </div>

      <p className="text-[11px] leading-snug text-white/40">
        Dentro de tu código ya existe <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">TAG</code>, la etiqueta de esta
        capa (<code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">{`P .. '${layerName}'`}</code>), así que{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">setProperty(TAG .. '.x', 0)</code> apunta siempre al sprite
        correcto aunque le cambies el nombre. Todo va envuelto en{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">do...end</code>, así que tus{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-violet-200">local</code> no chocan con los de otros comportamientos.
      </p>

      <Btn variant="soft" className="w-full" onClick={() => setShowOut((v) => !v)}>
        {showOut ? 'Ocultar' : 'Ver'} el Lua que se exporta
      </Btn>
      {showOut && (
        <pre className="max-h-56 overflow-auto rounded-xl border border-white/10 bg-[#080612] p-2.5 font-mono text-[11px] leading-relaxed text-cyan-100/80">
          {lines.length ? out : '-- escribe algo arriba y aquí verás exactamente qué se inyecta'}
        </pre>
      )}
      {!lines.length && <p className="text-[11px] leading-snug text-amber-200/70">Este comportamiento no exporta nada hasta que le pongas código.</p>}
    </>
  );
}

/* ---------- «Shader propio (.frag)»: el fragment shader de la persona, corre con WebGL ---------- */

function FragBehavior({ b, onChange }: { b: Behavior; onChange: (patch: Partial<Behavior>) => void }) {
  const code = b.fragCode ?? '';
  const [err, setErr] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);

  // comprueba si compila con un pequeno retraso para no recompilar a cada tecla
  useEffect(() => {
    if (!code.trim()) {
      setErr(null);
      setChecking(false);
      return;
    }
    setChecking(true);
    const id = window.setTimeout(() => {
      setErr(checkFrag(code));
      setChecking(false);
    }, 350);
    return () => window.clearTimeout(id);
  }, [code]);

  return (
    <>
      <p className="text-[11px] leading-snug text-white/40">
        Un <b className="text-white/60">fragment shader</b> de Psych Engine / P-Slice, escrito por ti. Se aplica a esta capa, se ve en la
        vista previa al darle a ▶ (corre en WebGL, optimizado) y se exporta tal cual como{' '}
        <span className="font-mono">shaders/&lt;nombre&gt;.frag</span>.
      </p>
      <p className="text-[10px] leading-snug text-white/35">
        Si la capa lleva además un shader Erect (adjustColor/dropShadow), no se pisan: el Erect se aplica primero y tu .frag encima.
      </p>

      <Field label="Código del shader (.frag)">
        <textarea
          value={code}
          spellCheck={false}
          rows={Math.min(18, Math.max(8, code.split('\n').length + 2))}
          placeholder={'#pragma header\n\nvoid main()\n{\n    vec4 color = flixel_texture2D(bitmap, openfl_TextureCoordv);\n    gl_FragColor = color;\n}'}
          onChange={(e) => onChange({ fragCode: e.target.value })}
          onKeyDown={(e) => {
            if (e.key !== 'Tab') return;
            e.preventDefault();
            const el = e.currentTarget;
            const a = el.selectionStart;
            const z = el.selectionEnd;
            const next = code.slice(0, a) + '    ' + code.slice(z);
            onChange({ fragCode: next });
            requestAnimationFrame(() => {
              el.selectionStart = el.selectionEnd = a + 4;
            });
          }}
          className="w-full resize-y overflow-x-auto whitespace-pre rounded-xl border border-white/10 border-l-2 border-l-cyan-400/60 bg-[#061018] px-3 py-2.5 font-mono text-[12px] leading-relaxed text-cyan-100/90 outline-none placeholder:text-white/20 focus:border-cyan-400/60 focus:border-l-cyan-300"
        />
      </Field>

      {code.trim() ? (
        checking ? (
          <p className="flex items-center gap-1.5 text-[11px] text-white/40">
            <Loader2 size={12} className="animate-spin" /> Comprobando si compila…
          </p>
        ) : err ? (
          <p className="rounded-lg bg-rose-500/10 px-2 py-1.5 text-[11px] leading-snug text-rose-200">
            <b>No compila:</b> <span className="font-mono text-[10px]">{err}</span>
          </p>
        ) : (
          <p className="rounded-lg bg-emerald-500/10 px-2 py-1.5 text-[11px] text-emerald-200">Compila · dale a ▶ para verlo sobre la capa</p>
        )
      ) : (
        <p className="text-[11px] leading-snug text-amber-200/70">Este comportamiento no pinta nada hasta que le pongas un shader.</p>
      )}

      <p className="text-[11px] leading-snug text-white/40">
        Dentro del shader tienes <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-cyan-200">openfl_TextureCoordv</code> (la
        coordenada UV, de 0 a 1), <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-cyan-200">bitmap</code> (la imagen de la
        capa, se lee con <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-cyan-200">flixel_texture2D(bitmap, uv)</code>),{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-cyan-200">uTime</code> (segundos, para animarlo) y{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-cyan-200">openfl_TextureSize</code>. Empieza con{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-cyan-200">#pragma header</code> y acaba escribiendo{' '}
        <code className="rounded bg-black/40 px-1 font-mono text-[10px] text-cyan-200">gl_FragColor</code>.
      </p>
      <p className="text-[11px] leading-snug text-white/35">
        Viene con un ejemplo que ondula la imagen: míralo con ▶ y cámbialo por el tuyo (glitch, agua, lo que necesites).
      </p>
    </>
  );
}
