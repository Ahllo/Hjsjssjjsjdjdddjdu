import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { Bookmark, Check, Download, FolderPlus, Layers, Loader2, Pencil, Play, Save, Sparkles, Star, Trash2, X } from 'lucide-react';
import { useEditor } from '../store';
import type { SavedStage, StageCategory } from '../types';
import { BASE_STAGES, exportNameFor, loadBaseStage, type BaseStageDef, type LoadProgress } from '../lib/baseStages';
import { ERECT_STAGES, FUNKIN_RAW, PSLICE_STAGES, erectKey, loadErectStage, type ErectStageDef } from '../lib/erectStages';
import { PSLICE_PIN, PSLICE_REPO } from '../lib/charlib';
import {
  createStageCategory,
  cssColor,
  deleteSavedStage,
  deleteStageCategory,
  ensureSavedStages,
  exportSavedStageFile,
  makeStageThumb,
  openSavedStage,
  refreshStageThumb,
  relTime,
  saveCurrentStage,
  savedBytes,
  stageCatCounts,
  suggestCatColor,
  updateSavedStage,
  updateStageCategory,
} from '../lib/savedStages';
import { loadDemo } from '../lib/demo';
import { fmtBytes } from '../lib/util';
import { Btn, ColorInput, Section, Toggle } from './ui';
import { cn } from '../utils/cn';

const RAW = 'https://raw.githubusercontent.com/ShadowMario/FNF-PsychEngine/5c67ced49e5a98535298a6daa3f8f4ec79ac8399/';
const PSLICE_RAW = `https://raw.githubusercontent.com/${PSLICE_REPO}/${PSLICE_PIN}/assets/base_game/week_data/`;

/** Proyectos que vienen por defecto: el ejemplo + los escenarios oficiales de Psych Engine */
export default function BaseStagesPanel() {
  const toast = useEditor((s) => s.toast);
  const current = useEditor((s) => s.project.settings.name);
  const [withChars, setWithChars] = useState(true);
  const [busy, setBusy] = useState<LoadProgress | null>(null);
  const [warns, setWarns] = useState<string[]>([]);

  const saved = useEditor((s) => s.savedStages);
  const stageCats = useEditor((s) => s.stageCats);
  /* ---- biblioteca propia: categorías y escenarios guardados ---- */
  const [opening, setOpening] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [formBusy, setFormBusy] = useState(false);
  const [formId, setFormId] = useState<string | null>(null);
  const [fName, setFName] = useState('');
  const [fDesc, setFDesc] = useState('');
  const [fCat, setFCat] = useState<string | null>(null);
  const [fColor, setFColor] = useState('');
  const [fBadge, setFBadge] = useState('');
  const [fThumb, setFThumb] = useState<string | undefined>(undefined);
  const [fNewCat, setFNewCat] = useState('');
  const [catOpen, setCatOpen] = useState(false);
  const [catId, setCatId] = useState<string | null>(null);
  const [cName, setCName] = useState('');
  const [cColor, setCColor] = useState('10B981');
  const [cDesc, setCDesc] = useState('');

  useEffect(() => {
    void ensureSavedStages();
  }, []);

  const counts = useMemo(() => stageCatCounts(saved), [saved]);
  const byCat = (id: string) => saved.filter((s) => s.catId === id).sort((a, b) => b.savedAt - a.savedAt);
  const free = useMemo(() => saved.filter((s) => !s.catId).sort((a, b) => b.savedAt - a.savedAt), [saved]);
  /** color que tendrá la tarjeta: el suyo propio, si no el de su categoría, si no el verde */
  const accent = cssColor(fColor || stageCats.find((c) => c.id === fCat)?.color || '10B981');

  const openNew = () => {
    setFormId(null);
    setFName(current && current !== 'nochefunkin' ? current : 'Mi escenario');
    setFDesc('');
    setFColor('');
    setFBadge('');
    setFCat(null);
    setFThumb(undefined);
    // se compone en segundo plano: la hoja se abre al instante y la vista aparece sola
    void makeStageThumb().then((t) => setFThumb(t));
    setFNewCat('');
    setFormOpen(true);
  };

  const openForm = (s: SavedStage) => {
    setFormId(s.id);
    setFName(s.name);
    setFDesc(s.desc ?? '');
    setFColor(s.color ?? '');
    setFBadge(s.badge ?? '');
    setFCat(s.catId ?? null);
    setFThumb(s.thumb);
    setFNewCat('');
    setFormOpen(true);
  };

  const submitForm = async () => {
    if (formBusy || !fName.trim()) return;
    if (formId) {
      if (!updateSavedStage(formId, { name: fName, desc: fDesc, color: fColor, badge: fBadge, catId: fCat })) {
        toast('Ponle un nombre al escenario', 'err');
        return;
      }
      toast(`"${fName.trim()}" actualizado`);
      setFormOpen(false);
      return;
    }
    setFormBusy(true);
    try {
      const e = await saveCurrentStage(fName, fCat, fDesc, fColor, fBadge);
      const where = useEditor.getState().stageCats.find((c) => c.id === e.catId)?.name;
      toast(`"${e.name}" guardado${where ? ` en "${where}"` : ' en tu biblioteca'} · ${fmtBytes(e.bytes)}`);
      setFormOpen(false);
    } catch (err) {
      toast('No se pudo guardar: ' + ((err as Error)?.message || 'error'), 'err');
    } finally {
      setFormBusy(false);
    }
  };

  const openCatSheet = (c: StageCategory | null) => {
    setCName(c?.name ?? '');
    setCColor(c?.color ?? suggestCatColor());
    setCDesc(c?.desc ?? '');
    setCatId(c?.id ?? null);
    setCatOpen(true);
  };

  const submitCat = () => {
    if (catId) {
      if (!updateStageCategory(catId, { name: cName, color: cColor, desc: cDesc })) {
        toast(cName.trim() ? 'Ya tienes una categoría con ese nombre' : 'Ponle un nombre a la categoría', 'err');
        return;
      }
      toast('Categoría actualizada');
    } else {
      const c = createStageCategory(cName, cColor, cDesc);
      if (!c) {
        toast(cName.trim() ? 'Ya tienes una categoría con ese nombre' : 'Ponle un nombre a la categoría', 'err');
        return;
      }
      toast(`Categoría "${c.name}" creada`);
    }
    setCatOpen(false);
  };

  const openSaved = async (s: SavedStage) => {
    if (busy || opening) return;
    if (!confirm(`¿Abrir "${s.name}"? Se reemplazará el proyecto actual (guárdalo antes si lo necesitas).`)) return;
    setOpening(s.id);
    setWarns([]);
    try {
      const n = await openSavedStage(s.id);
      toast(`"${n}" abierto desde tu biblioteca`);
    } catch (e) {
      toast('No se pudo abrir: ' + ((e as Error)?.message || 'error'), 'err');
    } finally {
      setOpening(null);
    }
  };

  const drop = async (s: SavedStage) => {
    if (!confirm(`¿Borrar "${s.name}" de tu biblioteca? Se liberan ${fmtBytes(s.bytes)}.`)) return;
    await deleteSavedStage(s.id);
    toast(`"${s.name}" borrado`);
  };

  const download = async (s: SavedStage) => {
    if (await exportSavedStageFile(s.id)) toast(`Descargado "${s.name}.psychstage"`);
    else toast('No se encontró el paquete guardado', 'err');
  };

  const open = async (def: BaseStageDef) => {
    if (busy) return;
    if (!confirm(`¿Abrir el escenario oficial "${def.name}"? Se reemplazará el proyecto actual (guárdalo antes si lo necesitas).`)) return;
    setWarns([]);
    setBusy({ stage: def.name, done: 0, total: 1, label: 'descargando' });
    try {
      const w = await loadBaseStage(def, withChars, setBusy);
      setWarns(w);
      toast(`"${def.name}" listo. Se exportará como "${exportNameFor(def.id)}".`);
    } catch (e) {
      toast('No se pudo cargar: ' + ((e as Error)?.message || 'sin conexión'), 'err');
    } finally {
      setBusy(null);
    }
  };

  const openErect = async (def: ErectStageDef) => {
    if (busy) return;
    if (!confirm(`¿Abrir "${def.name}"? Se reemplazará el proyecto actual (guárdalo antes si lo necesitas).`)) return;
    setWarns([]);
    setBusy({ stage: def.name, done: 0, total: 1, label: 'descargando' });
    try {
      const w = await loadErectStage(def, withChars, setBusy);
      setWarns(w);
      toast(`"${def.name}" listo. Se exportará como "${erectKey(def)}".`);
    } catch (e) {
      toast('No se pudo cargar: ' + ((e as Error)?.message || 'sin conexión'), 'err');
    } finally {
      setBusy(null);
    }
  };

  return (
    <Section title="Proyectos por defecto · Escenarios de Psych" icon={<Star size={15} />}>
      <p className="text-[11px] leading-snug text-white/50">
        Los escenarios oficiales de Psych Engine con sus <b className="text-white/75">mecánicas</b> (tren, ventanas, rayos, tanque, bailarinas…) convertidas en comportamientos que puedes editar
        o copiar a cualquier escenario tuyo. Las imágenes se descargan del repositorio oficial de Psych (una vez).
      </p>
      <Toggle checked={withChars} onChange={setWithChars} label="Cargar también sus personajes" hint="Pico, Mommy, Senpai, Tankman… para verlo como en el juego." />

      {busy && (
        <div className="space-y-1.5 rounded-xl border border-fuchsia-400/30 bg-fuchsia-500/10 p-2.5">
          <p className="flex items-center gap-2 text-[12px] font-semibold text-white">
            <Loader2 size={14} className="animate-spin text-fuchsia-300" /> {busy.stage}: {busy.label}
          </p>
          <div className="h-1.5 overflow-hidden rounded-full bg-white/10">
            <div className="h-full bg-gradient-to-r from-violet-400 to-fuchsia-400 transition-all" style={{ width: `${Math.min(100, (busy.done / Math.max(1, busy.total)) * 100)}%` }} />
          </div>
        </div>
      )}

      {/* ------------------------- tus escenarios guardados ------------------------- */}
      <div className="space-y-3 rounded-2xl border border-emerald-400/20 bg-emerald-500/[0.05] p-3">
        <div className="flex items-start gap-2.5">
          <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-emerald-500/20 text-emerald-300 shadow-[0_0_18px_rgba(16,185,129,.20)]">
            <Bookmark size={15} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[13px] font-bold text-white">Tus escenarios</p>
            <p className="text-[11px] leading-snug text-white/45">
              Guarda el que tengas abierto ahora mismo —uno tuyo desde cero, un oficial retocado o un Erect— con todas sus
              imágenes dentro. Tus categorías funcionan igual que las secciones de abajo: nombre, color y descripción propios
              encabezando su rejilla de tarjetas.
            </p>
          </div>
          {saved.length > 0 && (
            <span className="mt-0.5 shrink-0 rounded-md bg-white/[0.06] px-1.5 py-0.5 text-[10px] font-bold text-white/50">
              {saved.length} · {fmtBytes(savedBytes(saved))}
            </span>
          )}
        </div>

        <button
          onClick={openNew}
          disabled={!!busy || formBusy}
          className="flex min-h-[42px] w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-[13px] font-bold text-[#04140f] shadow-lg shadow-emerald-500/20 transition active:scale-[0.98] disabled:opacity-50"
        >
          {formBusy ? <Loader2 size={15} className="animate-spin" /> : <Save size={15} />} Guardar el escenario actual
        </button>

        <div className="space-y-1.5">
          <p className="text-[11px] font-bold uppercase tracking-widest text-emerald-200/70">Tus categorías</p>
          <div className="-mx-1 flex gap-1.5 overflow-x-auto px-1 pb-0.5">
            <button
              onClick={() => openCatSheet(null)}
              className="flex h-8 shrink-0 items-center gap-1.5 rounded-full border border-dashed border-emerald-400/45 px-3 text-[12px] font-bold text-emerald-200 transition active:scale-95"
            >
              <FolderPlus size={13} /> Nueva
            </button>
            {stageCats.map((c) => (
              <button
                key={c.id}
                onClick={() => openCatSheet(c)}
                title="Nombre, color y descripción"
                className="flex h-8 shrink-0 items-center gap-1.5 rounded-full border px-3 text-[12px] font-semibold text-white transition active:scale-95"
                style={{ borderColor: cssColor(c.color) + '66', background: cssColor(c.color) + '1f' }}
              >
                <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ background: cssColor(c.color) }} />
                <span className="max-w-[9rem] truncate">{c.name}</span>
                <span className="font-mono text-[10px] text-white/45">{counts.get(c.id) ?? 0}</span>
              </button>
            ))}
          </div>
          <p className="text-[11px] leading-snug text-white/40">Toca una para cambiarle el nombre, el color (libre, con el selector) y la descripción.</p>
        </div>
      </div>

      {saved.length === 0 ? (
        <p className="rounded-xl border border-dashed border-white/15 bg-black/20 p-4 text-center text-[11px] leading-snug text-white/40">
          Todavía no guardaste ningún escenario. Arma el tuyo (o abre uno de los de abajo y retócalo) y toca{' '}
          <b className="text-emerald-200/80">Guardar el escenario actual</b>.
        </p>
      ) : (
        <>
          {stageCats.map((c) => {
            const members = byCat(c.id);
            return (
              <div key={c.id}>
                <div className="space-y-1 pt-1">
                  <p className="text-[11px] font-bold uppercase tracking-widest" style={{ color: cssColor(c.color) }}>
                    {c.name} <span className="font-mono text-white/30">({members.length})</span>
                  </p>
                  {c.desc ? <p className="text-[11px] leading-snug text-white/45">{c.desc}</p> : null}
                </div>
                {members.length ? (
                  <div className="grid grid-cols-2 gap-2">
                    {members.map((s) => (
                      <StageCard
                        key={s.id}
                        s={s}
                        cat={c}
                        opening={opening === s.id}
                        onOpen={() => openSaved(s)}
                        onEdit={() => openForm(s)}
                        onExport={() => download(s)}
                        onDelete={() => drop(s)}
                      />
                    ))}
                  </div>
                ) : (
                  <p className="rounded-xl border border-dashed border-white/12 bg-black/20 p-3 text-center text-[11px] text-white/35">
                    Categoría vacía: guarda un escenario aquí o muévelo con el lápiz de su tarjeta.
                  </p>
                )}
              </div>
            );
          })}
          {free.length > 0 && (
            <div>
              <div className="space-y-1 pt-1">
                <p className="text-[11px] font-bold uppercase tracking-widest text-white/45">Sin categoría ({free.length})</p>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {free.map((s) => (
                  <StageCard
                    key={s.id}
                    s={s}
                    opening={opening === s.id}
                    onOpen={() => openSaved(s)}
                    onEdit={() => openForm(s)}
                    onExport={() => download(s)}
                    onDelete={() => drop(s)}
                  />
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* hoja de la categoría: nombre, color libre y descripción */}
      {catOpen && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 p-4 sm:items-center" onClick={() => setCatOpen(false)}>
          <div
            className="w-full max-w-sm rounded-2xl border bg-[#141126] p-3 shadow-2xl"
            style={{ borderColor: cssColor(cColor) + '66' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-2.5 flex items-center gap-2">
              <span className="h-4 w-4 shrink-0 rounded-full transition-colors" style={{ background: cssColor(cColor), boxShadow: `0 0 12px ${cssColor(cColor)}88` }} />
              <p className="min-w-0 flex-1 truncate text-[13px] font-bold text-white">{catId ? cName || 'Categoría' : 'Nueva categoría'}</p>
              <button onClick={() => setCatOpen(false)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/60 active:bg-white/10" aria-label="Cerrar">
                <X size={16} />
              </button>
            </div>
            <label className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-white/45">Nombre</label>
            <input
              autoFocus
              value={cName}
              maxLength={28}
              onChange={(e) => setCName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submitCat()}
              placeholder="Mis WIP, Semana 9, Erect…"
              className="mb-2.5 h-10 w-full rounded-xl border border-white/10 bg-black/40 px-3 text-[13px] text-white outline-none placeholder:text-white/25 focus:border-white/35"
            />
            <label className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-white/45">Color</label>
            <ColorInput value={cColor} onChange={setCColor} />
            <p className="mb-2.5 mt-1 text-[11px] leading-snug text-white/40">
              El que quieras, sin paleta cerrada: encabeza la sección y tiñe las insignias de sus tarjetas.
            </p>
            <label className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-white/45">Descripción (opcional)</label>
            <textarea
              value={cDesc}
              maxLength={140}
              rows={2}
              onChange={(e) => setCDesc(e.target.value)}
              placeholder="Qué guardas aquí y para qué es…"
              className="mb-1 w-full resize-none rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-[12px] leading-snug text-white outline-none placeholder:text-white/25 focus:border-white/35"
            />
            <p className="mb-2.5 text-right font-mono text-[10px] text-white/30">{cDesc.length}/140 · si lo dejas vacío no sale</p>
            <div className="flex gap-2">
              <Btn className="flex-1" onClick={() => setCatOpen(false)}>
                Cancelar
              </Btn>
              {catId && (
                <button
                  title="Borrar la categoría"
                  onClick={() => {
                    const c = stageCats.find((x) => x.id === catId);
                    if (!c) return;
                    const n = counts.get(c.id) ?? 0;
                    if (!confirm(`¿Borrar la categoría "${c.name}"?${n ? ` Sus ${n} escenario${n === 1 ? '' : 's'} vuelven a "Sin categoría", no se borran.` : ''}`)) return;
                    deleteStageCategory(c.id);
                    setCatOpen(false);
                    toast(`Categoría "${c.name}" borrada`);
                  }}
                  className="flex min-h-[38px] shrink-0 items-center justify-center rounded-xl bg-rose-500/15 px-3 text-rose-300 transition active:scale-95"
                >
                  <Trash2 size={14} />
                </button>
              )}
              <button
                onClick={submitCat}
                disabled={!cName.trim()}
                className="flex min-h-[38px] flex-1 items-center justify-center gap-1.5 rounded-xl px-3 text-[13px] font-bold text-[#04140f] transition active:scale-[0.97] disabled:opacity-40"
                style={{ background: cssColor(cColor) }}
              >
                <Check size={15} /> {catId ? 'Guardar' : 'Crear'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* hoja del escenario: nombre, descripción y categoría */}
      {formOpen && (
        <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/70 p-4 sm:items-center" onClick={() => !formBusy && setFormOpen(false)}>
          <div className="max-h-[88vh] w-full max-w-md overflow-y-auto rounded-2xl border border-emerald-400/25 bg-[#101a17] p-3 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-2.5 flex items-center gap-2">
              {formId ? <Pencil size={15} className="text-emerald-300" /> : <Save size={15} className="text-emerald-300" />}
              <p className="min-w-0 flex-1 text-[13px] font-bold text-white">{formId ? 'Editar escenario' : 'Guardar el escenario actual'}</p>
              <button onClick={() => setFormOpen(false)} className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/60 active:bg-white/10" aria-label="Cerrar">
                <X size={16} />
              </button>
            </div>
            <div className="overflow-hidden rounded-xl border border-white/10 bg-[#0b0916]">
              {fThumb ? (
                <img src={fThumb} alt="" className="h-32 w-full object-contain" />
              ) : (
                <div className="flex h-32 items-center justify-center gap-1.5 text-[11px] text-white/35">
                  <Layers size={14} /> El escenario abierto no tiene capas
                </div>
              )}
            </div>
            <p className="mb-2.5 mt-1 text-[10px] leading-snug text-white/35">
              El escenario entero, encuadrado de punta a punta —no un recorte de lo que se ve en la ventana.
            </p>
            {formId && (
              <Btn
                variant="soft"
                className="mb-2.5 h-8 w-full text-[11px]"
                onClick={async () => {
                  const t = await refreshStageThumb(formId);
                  if (!t) {
                    toast('El escenario abierto no tiene nada que dibujar', 'err');
                    return;
                  }
                  setFThumb(t);
                  toast('Miniatura rehecha con el escenario que hay abierto');
                }}
              >
                <Layers size={13} /> Rehacer la miniatura con lo abierto
              </Btn>
            )}
            <label className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-emerald-200/70">Nombre</label>
            <input
              autoFocus
              value={fName}
              maxLength={40}
              onChange={(e) => setFName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && fName.trim() && submitForm()}
              className="mb-2.5 h-10 w-full rounded-xl border border-white/10 bg-black/40 px-3 text-[13px] text-white outline-none focus:border-emerald-400/60"
            />
            <label className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-emerald-200/70">Descripción (opcional)</label>
            <textarea
              value={fDesc}
              maxLength={140}
              rows={2}
              onChange={(e) => setFDesc(e.target.value)}
              placeholder="Qué tiene: tren, rayos, parallax, para qué canción…"
              className="mb-1 w-full resize-none rounded-xl border border-white/10 bg-black/40 px-3 py-2 text-[12px] leading-snug text-white outline-none placeholder:text-white/25 focus:border-emerald-400/60"
            />
            <p className="mb-2.5 text-right font-mono text-[10px] text-white/30">{fDesc.length}/140 · si lo dejas vacío no sale</p>
            <label className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-emerald-200/70">Color de la tarjeta</label>
            {fColor ? (
              <div className="mb-1 flex gap-1.5">
                <div className="min-w-0 flex-1">
                  <ColorInput value={fColor} onChange={setFColor} />
                </div>
                <Btn className="h-10 shrink-0" onClick={() => setFColor('')}>
                  Heredar
                </Btn>
              </div>
            ) : (
              <Btn
                variant="soft"
                className="mb-1 w-full"
                onClick={() => setFColor((stageCats.find((c) => c.id === fCat)?.color ?? suggestCatColor()).replace(/^#/, ''))}
              >
                <Pencil size={13} /> Elegir un color propio
              </Btn>
            )}
            <p className="mb-2.5 text-[11px] leading-snug text-white/40">
              {fColor ? 'Tiñe la franja, la insignia y la descripción de su tarjeta.' : 'Sin color propio: hereda el de su categoría.'}
            </p>
            <label className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-emerald-200/70">Palabra en la tarjeta (opcional)</label>
            <input
              value={fBadge}
              maxLength={18}
              onChange={(e) => setFBadge(e.target.value)}
              placeholder="Mío, WIP, Boss, Semana 9…"
              className="mb-1.5 h-10 w-full rounded-xl border border-white/10 bg-black/40 px-3 text-[13px] text-white outline-none placeholder:text-white/25 focus:border-emerald-400/60"
            />
            <div className="relative mb-1 h-12 overflow-hidden rounded-lg border border-white/10 bg-[#0b0916]">
              {fThumb ? <img src={fThumb} alt="" className="h-full w-full object-contain opacity-75" /> : <NoThumb />}
              <span className="absolute inset-x-0 bottom-0 h-[2px] opacity-75" style={{ background: accent }} />
              {fBadge.trim() ? (
                <span
                  className="absolute left-1 top-1 inline-flex max-w-[8rem] items-center rounded-md px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wide text-[#0b0916]"
                  style={{ background: accent }}
                >
                  <span className="truncate">{fBadge.trim()}</span>
                </span>
              ) : null}
              <span className="absolute bottom-1.5 right-1.5 text-[9px] font-bold uppercase tracking-wider text-white/30">así se verá</span>
            </div>
            <p className="mb-2.5 text-[11px] leading-snug text-white/40">
              {fBadge.trim() ? 'Esa palabra va en la esquina de la tarjeta, con el color de arriba.' : 'Si lo dejas vacío, la tarjeta no lleva insignia.'}
            </p>
            <label className="mb-1 block text-[11px] font-medium uppercase tracking-wider text-emerald-200/70">Categoría</label>
            <div className="-mx-1 mb-2 flex gap-1.5 overflow-x-auto px-1 pb-1">
              <CatChip label="Sin categoría" active={fCat === null} hideCount onClick={() => setFCat(null)} />
              {stageCats.map((c) => (
                <CatChip key={c.id} label={c.name} count={counts.get(c.id) ?? 0} color={cssColor(c.color)} active={fCat === c.id} onClick={() => setFCat(c.id)} />
              ))}
            </div>
            <div className="mb-2.5 flex gap-1.5">
              <input
                value={fNewCat}
                maxLength={28}
                onChange={(e) => setFNewCat(e.target.value)}
                placeholder="…o crea una categoría nueva"
                className="h-9 min-w-0 flex-1 rounded-lg border border-white/10 bg-black/40 px-2.5 text-[12px] text-white outline-none placeholder:text-white/25 focus:border-emerald-400/60"
              />
              <Btn
                variant="soft"
                className="h-9 shrink-0"
                disabled={!fNewCat.trim()}
                onClick={() => {
                  const c = createStageCategory(fNewCat);
                  if (!c) {
                    toast('Ya tienes una categoría con ese nombre', 'err');
                    return;
                  }
                  setFCat(c.id);
                  setFNewCat('');
                  toast(`Categoría "${c.name}" creada`);
                }}
              >
                <FolderPlus size={14} /> Crear
              </Btn>
            </div>
            {!formId && (
              <p className="mb-2.5 text-[11px] leading-snug text-white/40">
                Se guarda una copia completa con sus imágenes: podrás abrirla aunque después cargues otros escenarios.
              </p>
            )}
            <div className="flex gap-2">
              <Btn className="flex-1" disabled={formBusy} onClick={() => setFormOpen(false)}>
                Cancelar
              </Btn>
              <button
                onClick={submitForm}
                disabled={formBusy || !fName.trim()}
                className="flex min-h-[38px] flex-1 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 px-3 text-[13px] font-bold text-[#04140f] shadow-lg shadow-emerald-500/20 transition active:scale-[0.97] disabled:opacity-40"
              >
                {formBusy ? <Loader2 size={15} className="animate-spin" /> : <Check size={15} />} {formId ? 'Guardar cambios' : 'Guardar'}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-2 gap-2">
        <button
          disabled={!!busy}
          onClick={() => {
            if (confirm('¿Cargar el escenario de ejemplo? Se reemplazará el proyecto actual.')) loadDemo();
          }}
          className={cn(
            'group overflow-hidden rounded-xl border text-left transition hover:-translate-y-0.5 hover:bg-black/40 active:scale-[0.98]',
            current === 'nochefunkin' ? 'border-fuchsia-400/60' : 'border-white/10 hover:border-white/25',
            'bg-black/25',
          )}
        >
          <div className="flex h-16 items-center justify-center bg-gradient-to-br from-violet-900 via-fuchsia-900 to-rose-700">
            <Sparkles className="text-fuchsia-200" size={22} />
          </div>
          <div className="p-2">
            <p className="text-[12px] font-bold text-white">Ejemplo</p>
            <p className="text-[10px] text-white/45">Noche Funkin' · por defecto</p>
          </div>
        </button>
        {BASE_STAGES.map((def) => (
          <button
            key={def.id}
            disabled={!!busy}
            onClick={() => open(def)}
            className={cn(
              'group overflow-hidden rounded-xl border bg-black/25 text-left transition hover:-translate-y-0.5 hover:bg-black/40 active:scale-[0.98] disabled:opacity-50 disabled:hover:translate-y-0',
              current === exportNameFor(def.id) ? 'border-fuchsia-400/60' : 'border-white/10 hover:border-white/25',
            )}
          >
            <div className="relative h-16 overflow-hidden bg-[#1a1530]">
              <img
                src={RAW + def.thumb}
                alt=""
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.06]"
                style={{ imageRendering: def.pixel ? 'pixelated' : undefined }}
              />
              <span className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-md bg-black/60 text-white/80">
                <Download size={11} />
              </span>
            </div>
            <div className="p-2">
              <p className="text-[12px] font-bold text-white">{def.name}</p>
              <p className="text-[10px] text-white/45">{def.week}</p>
              <p className="mt-0.5 line-clamp-2 text-[10px] leading-tight text-fuchsia-200/70">{def.mechanics.join(' · ')}</p>
            </div>
          </button>
        ))}
      </div>

      <div className="space-y-1 pt-1">
        <p className="text-[11px] font-bold uppercase tracking-widest text-cyan-200/70">P-Slice · Weekend 1 · Darnell (normal)</p>
        <p className="text-[11px] leading-snug text-white/45">
          Philly Streets normal de P-Slice, con la capa de ciudad que faltaba, humo en su sitio, coches y Nene/Pico jugable.
        </p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {PSLICE_STAGES.map((def) => (
          <button
            key={erectKey(def)}
            disabled={!!busy}
            onClick={() => openErect(def)}
            className={cn(
              'group overflow-hidden rounded-xl border bg-black/25 text-left transition hover:-translate-y-0.5 hover:bg-black/40 active:scale-[0.98] disabled:opacity-50 disabled:hover:translate-y-0',
              current === erectKey(def) ? 'border-cyan-400/60' : 'border-white/10 hover:border-white/25',
            )}
          >
            <div className="relative h-16 overflow-hidden bg-[#1a1530]">
              <img src={PSLICE_RAW + def.thumb} alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.06]" />
              <span className="absolute left-1 top-1 rounded-md bg-cyan-600/90 px-1.5 py-0.5 text-[9px] font-black uppercase text-white">P-Slice</span>
            </div>
            <div className="p-2">
              <p className="text-[12px] font-bold text-white">{def.name}</p>
              <p className="text-[10px] text-white/45">{def.usedBy}</p>
              <p className="mt-0.5 line-clamp-2 text-[10px] leading-tight text-cyan-200/70">{def.mechanics.join(' · ')}</p>
            </div>
          </button>
        ))}
      </div>

      <div className="space-y-1 pt-1">
        <p className="text-[11px] font-bold uppercase tracking-widest text-fuchsia-200/70">Erect · Pico Mix · BF Mix</p>
        <p className="text-[11px] leading-snug text-white/45">
          Psych no los trae: vienen de los assets oficiales de FNF/P-Slice y se convierten con posiciones, animaciones y los shaders de cada script. School y Tank Erect tienen variantes BF/GF y Pico/Nene. Darnell normal y los BF Mix tienen su Philly Streets.
        </p>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {ERECT_STAGES.map((def) => (
          <button
            key={erectKey(def)}
            disabled={!!busy}
            onClick={() => openErect(def)}
            className={cn(
              'group overflow-hidden rounded-xl border bg-black/25 text-left transition hover:-translate-y-0.5 hover:bg-black/40 active:scale-[0.98] disabled:opacity-50 disabled:hover:translate-y-0',
              current === erectKey(def) ? (def.credit ? 'border-red-400/70' : 'border-fuchsia-400/60') : 'border-white/10 hover:border-white/25',
            )}
          >
            <div className="relative h-16 overflow-hidden bg-[#1a1530]">
              <img
                src={(def.thumbSrc === 'pslice' ? PSLICE_RAW : FUNKIN_RAW) + def.thumb}
                alt=""
                loading="lazy"
                className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-[1.06]"
                style={{ imageRendering: def.pixel ? 'pixelated' : undefined, filter: def.thumbFilter }}
              />
              <span className={cn('absolute left-1 top-1 rounded-md px-1.5 py-0.5 text-[9px] font-black uppercase text-white', def.credit ? 'bg-red-600/95' : 'bg-fuchsia-600/90')}>
                Erect
              </span>
              <span className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-md bg-black/60 text-white/80">
                <Download size={11} />
              </span>
            </div>
            <div className="p-2">
              <p className="text-[12px] font-bold text-white">{def.name}</p>
              <p className="text-[10px] text-white/45">
                {def.tag} · {def.usedBy}
              </p>
              <p className={cn('mt-0.5 line-clamp-2 text-[10px] leading-tight', def.credit ? 'text-red-200/75' : 'text-fuchsia-200/70')}>
                {def.mechanics.join(' · ')}
              </p>
              {def.credit && <p className="mt-1 line-clamp-2 text-[9px] leading-tight text-white/35">{def.credit}</p>}
            </div>
          </button>
        ))}
      </div>

      {warns.length > 0 && (
        <div className="space-y-1 rounded-xl bg-amber-500/10 p-2.5 text-[11px] text-amber-100">
          {warns.map((w, i) => (
            <p key={i}>⚠ {w}</p>
          ))}
        </div>
      )}
      <details className="rounded-xl bg-black/20 p-2.5 text-[11px] text-white/55">
        <summary className="cursor-pointer font-semibold text-white/75">Qué no se incluye (está programado en Haxe)</summary>
        <ul className="mt-1.5 list-disc space-y-0.5 pl-4">
          {BASE_STAGES.filter((d) => d.missing).map((d) => (
            <li key={d.id}>
              <b className="text-white/70">{d.name}:</b> {d.missing}
            </li>
          ))}
          {ERECT_STAGES.filter((d) => d.missing).map((d) => (
            <li key={erectKey(d)}>
              <b className="text-white/70">{d.name}:</b> {d.missing}
            </li>
          ))}
        </ul>
        <p className="mt-1.5">
          Se exportan con otro nombre (ej: <span className="font-mono">philly-custom</span>) porque Psych ejecuta el código Haxe del escenario original si se llama igual, y se duplicaría.
        </p>
      </details>
    </Section>
  );
}


/* ------------------------- biblioteca propia de escenarios ------------------------- */

/** Píldora para elegir en qué categoría va un escenario */
function CatChip({
  label,
  count,
  color,
  active,
  hideCount,
  onClick,
}: {
  label: string;
  count?: number;
  color?: string;
  active: boolean;
  hideCount?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        'flex h-8 shrink-0 items-center gap-1.5 rounded-full border px-3 text-[12px] font-semibold transition active:scale-95',
        active ? 'border-transparent text-white' : 'border-white/10 bg-white/[0.04] text-white/60',
      )}
      style={active ? { background: color ?? '#10b981', boxShadow: `0 2px 14px ${(color ?? '#10b981')}66` } : undefined}
    >
      {color && !active && <span className="h-2 w-2 shrink-0 rounded-full" style={{ background: color }} />}
      <span className="max-w-[9rem] truncate">{label}</span>
      {!hideCount && <span className={cn('font-mono text-[10px]', active ? 'text-white/75' : 'text-white/35')}>{count ?? 0}</span>}
    </button>
  );
}

function IconAct({ title, onClick, danger, children }: { title: string; onClick: () => void; danger?: boolean; children: ReactNode }) {
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      onClick={onClick}
      className={cn(
        'flex h-7 w-7 shrink-0 items-center justify-center rounded-lg transition active:scale-90',
        danger ? 'text-rose-300/70 hover:bg-rose-500/15 hover:text-rose-200' : 'text-white/45 hover:bg-white/10 hover:text-white/90',
      )}
    >
      {children}
    </button>
  );
}

/** Si el lienzo no dio miniatura, la tarjeta no se queda hueca: se dibuja una rejilla de capas */
function NoThumb() {
  return (
    <>
      <span className="absolute inset-0 bg-[linear-gradient(155deg,#1d1436_0%,#2a1a3f_55%,#3d2140_100%)]" />
      <span
        className="absolute inset-0 opacity-45"
        style={{
          backgroundImage:
            'repeating-linear-gradient(90deg,rgba(255,255,255,.10) 0 1px,transparent 1px 9px),repeating-linear-gradient(0deg,rgba(255,255,255,.07) 0 1px,transparent 1px 9px)',
        }}
      />
      <span className="absolute inset-0 flex items-center justify-center text-white/30">
        <Layers size={16} />
      </span>
    </>
  );
}

/** Tarjeta de un escenario guardado: la misma anatomía que las de los escenarios oficiales */
function StageCard({
  s,
  cat,
  opening,
  onOpen,
  onEdit,
  onExport,
  onDelete,
}: {
  s: SavedStage;
  cat?: StageCategory;
  opening: boolean;
  onOpen: () => void;
  onEdit: () => void;
  onExport: () => void;
  onDelete: () => void;
}) {
  const col = cssColor(s.color || cat?.color || '10B981');
  return (
    <div className="group overflow-hidden rounded-xl border border-white/10 bg-black/25 text-left transition hover:-translate-y-0.5 hover:border-white/25 hover:bg-black/40">
      <button onClick={onOpen} disabled={opening} className="block w-full text-left disabled:opacity-60">
        <div className="relative h-16 overflow-hidden bg-[#0b0916]">
          {s.thumb ? (
            <img src={s.thumb} alt="" draggable={false} className="h-full w-full object-contain transition-transform duration-500 group-hover:scale-[1.06]" />
          ) : (
            <NoThumb />
          )}
          {/* la franja del color va siempre: es la identidad de la tarjeta, haya insignia o no */}
          <span className="absolute inset-x-0 bottom-0 h-[2px] opacity-75 transition-opacity group-hover:opacity-100" style={{ background: col }} />
          {/* la insignia es la palabra que la persona escriba; si no escribió nada, no está */}
          {s.badge ? (
            <span
              className="absolute left-1 top-1 inline-flex max-w-[6.5rem] items-center rounded-md px-1.5 py-0.5 text-[9px] font-black uppercase tracking-wide text-[#0b0916] shadow-[0_1px_6px_rgba(0,0,0,.5)]"
              style={{ background: col }}
            >
              <span className="truncate">{s.badge}</span>
            </span>
          ) : null}
          <span className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-md bg-black/60 text-white/80">
            {opening ? <Loader2 size={11} className="animate-spin text-emerald-300" /> : <Play size={11} />}
          </span>
        </div>
        <div className="p-2">
          <p className="truncate text-[12px] font-bold text-white">{s.name}</p>
          <p className="text-[10px] text-white/45">
            {s.layers} capas · zoom {s.zoom} · Psych {s.target}
          </p>
          {s.desc ? (
            <p className="mt-0.5 line-clamp-2 text-[10px] leading-tight" style={{ color: col }}>
              {s.desc}
            </p>
          ) : null}
        </div>
      </button>
      <div className="flex items-center gap-0.5 border-t border-white/[0.06] px-1 py-0.5">
        <IconAct title="Editar nombre, descripción y categoría" onClick={onEdit}>
          <Pencil size={12} />
        </IconAct>
        <IconAct title="Descargar .psychstage" onClick={onExport}>
          <Download size={12} />
        </IconAct>
        <span className="flex-1" />
        <span className="mr-0.5 font-mono text-[9px] text-white/25">{s.directory || relTime(s.savedAt)}</span>
        <IconAct title="Borrar de la biblioteca" danger onClick={onDelete}>
          <Trash2 size={12} />
        </IconAct>
      </div>
    </div>
  );
}
