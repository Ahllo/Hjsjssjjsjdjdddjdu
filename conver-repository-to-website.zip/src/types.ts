export type CharKey = 'gf' | 'dad' | 'boyfriend';
export type LayerKind = 'sprite' | 'animated' | 'square' | CharKey;
export type Quality = 'both' | 'high' | 'low';
export type PlayMode = 'both' | 'story' | 'freeplay';
export type CamTarget = 'game' | 'hud' | 'other';
export type BlendName =
  | 'normal'
  | 'add'
  | 'multiply'
  | 'screen'
  | 'subtract'
  | 'lighten'
  | 'darken'
  | 'difference'
  | 'overlay'
  | 'hardlight'
  | 'invert';
export type TargetVersion = '0.6' | '0.7' | '1.0';
export type FocusKey = 'free' | CharKey;
export type BehaviorType =
  | 'beatAnim'
  | 'danceLR'
  | 'float'
  | 'spin'
  | 'scroll'
  | 'beatBump'
  | 'fade'
  /** ventanas de Philly: cambia de color cada N beats y se apaga poco a poco */
  | 'lightCycle'
  /** tren de Philly / coche de Limo: cruza la pantalla de vez en cuando */
  | 'passBy'
  /** tanque de la week 7: da vueltas en una elipse girando */
  | 'orbit'
  /** rayo de Spooky: animación + destello + zoom + personajes asustados */
  | 'lightning'
  /** lluvia del RainShader de P-Slice sobre la capa (árboles de Spooky Mansion Erect) */
  | 'rain'
  /**
   * Comportamiento propio: el código Lua que la persona escriba, inyectado tal cual en
   * onBeatHit o en onUpdate del .lua exportado, dentro del chequeo de que la capa existe.
   */
  | 'custom'
  /**
   * Shader propio: un fragment shader (.frag) de Psych/P-Slice escrito por la persona.
   * Se ejecuta en la vista previa con WebGL y se exporta como shaders/<nombre>.frag.
   */
  | 'frag';
export type BumpProp = 'scale' | 'alpha' | 'y' | 'angle';
export type PanelId = 'layers' | 'props' | 'stage' | 'extras' | 'assets' | 'export' | 'credits';

export interface AnimDef {
  id: string;
  /** nombre de la animación dentro del juego (ej: idle) */
  anim: string;
  /** prefijo del símbolo en el XML (ej: "crowd bop") */
  prefix: string;
  fps: number;
  loop: boolean;
  /** índices separados por coma, vacío = por prefijo */
  indices: string;
  offsetX: number;
  offsetY: number;
}

export interface Behavior {
  id: string;
  type: BehaviorType;
  enabled: boolean;
  anim: string;
  anim2: string;
  every: number;
  axis: 'x' | 'y';
  amount: number;
  period: number;
  phase: number;
  speed: number;
  speedY: number;
  range: number;
  prop: BumpProp;
  decay: number;
  min: number;
  max: number;
  /** lightCycle: colores separados por coma (hex) */
  colors: string;
  /** passBy: recorrido en X */
  startX: number;
  endX: number;
  loopX: number;
  finishX: number;
  repeats: number;
  /** passBy / lightning: probabilidad (%) en cada beat */
  chance: number;
  cooldown: number;
  /** passBy: GF hace hairBlow / hairFall (como el tren) */
  gfHair: boolean;
  /** passBy: segundos entre arrancar el sonido del tren y que entre en pantalla */
  delay: number;
  /** passBy: escoge una animación car1..carN al empezar */
  randomAnim: boolean;
  /** passBy: oculta el sprite cuando no está pasando (coches/estrellas) */
  hideWhenIdle: boolean;
  /** orbit */
  centerX: number;
  centerY: number;
  radiusX: number;
  radiusY: number;
  angleOffset: number;
  rotate: boolean;
  /** lightning */
  minGap: number;
  maxGap: number;
  flash: boolean;
  zoomBump: number;
  scare: boolean;
  /** rayos sincronizados: las capas con el mismo grupo caen a la vez */
  group: string;
  /** rayo: sonido (prefijo, se elige _1 o _2 al azar, ej: thunder) */
  sound: string;
  /** rayo (Spooky Mansion Erect): los personajes oscuros se cambian por su versión iluminada */
  litChars: boolean;
  /** rain: uScale del RainShader (FlxG.height / 200 * 2 = 7.2 a 720p) */
  rainScale: number;
  /** rain: uIntensity, 0 = sin lluvia y 1 = máximo */
  rainIntensity: number;
  /** custom: código Lua escrito por la persona */
  code: string;
  /** custom: en qué función del .lua se inyecta ese código */
  hook: 'beat' | 'update';
  /** frag: código del fragment shader (.frag) escrito por la persona */
  fragCode: string;
}

export type ShaderKind = 'none' | 'adjustColor' | 'dropShadow';

/**
 * Shader de escena Erect (adjustColor.frag / dropShadow.frag de Rozebud).
 * uFrameBounds y angOffset NO se guardan: los pone setShaderFrameInfo en cada frame.
 */
export interface ShaderFx {
  kind: ShaderKind;
  enabled: boolean;
  /** Adjust Color (los dos shaders lo tienen) */
  hue: number;
  saturation: number;
  brightness: number;
  contrast: number;
  /** dropShadow: ángulo en grados (se exporta con math.rad) */
  ang: number;
  dist: number;
  str: number;
  thr: number;
  aaStages: number;
  dropColor: string;
  /** máscara altMask: en personajes = automática (characters/masks/<hoja>_mask) */
  useMask: boolean;
  /** ruta manual de la máscara dentro de images/ (vacío = automática en personajes) */
  maskPath: string;
  thr2: number;
}

export interface Layer {
  id: string;
  kind: LayerKind;
  name: string;
  image: string;
  x: number;
  y: number;
  scaleX: number;
  scaleY: number;
  width: number;
  height: number;
  scrollX: number;
  scrollY: number;
  alpha: number;
  angle: number;
  color: string;
  antialiasing: boolean;
  flipX: boolean;
  flipY: boolean;
  visible: boolean;
  blend: BlendName;
  quality: Quality;
  mode: PlayMode;
  camera: CamTarget;
  animations: AnimDef[];
  firstAnimation: string;
  behaviors: Behavior[];
  /** efecto .frag de Psych Engine aplicado a esta capa */
  shader: ShaderFx | null;
  locked: boolean;
  hidden: boolean;
}

export interface CharAnim {
  anim: string;
  name: string;
  fps: number;
  loop: boolean;
  indices: number[];
  offsets: [number, number];
}

export interface CustomChar {
  fileName: string;
  image: string;
  assetId: string | null;
  /** hojas de sprites adicionales (Psych 1.0 permite "image": "a, b, c") */
  extraAssetIds?: string[];
  position: [number, number];
  cameraPosition: [number, number];
  scale: number;
  flipX: boolean;
  antialiasing: boolean;
  animations: CharAnim[];
  healthIcon?: string;
  healthColor?: string;
  source?: 'base' | 'user';
}

/** Categoría creada por el usuario para organizar su biblioteca de personajes */
export interface CharCategory {
  id: string;
  name: string;
  color: string;
  addedAt: number;
}

/**
 * Categoría propia de escenarios. Funciona como las secciones que ya vienen en el panel
 * (oficiales, P-Slice, Erect): un nombre, un color y una descripción que encabezan su
 * rejilla de tarjetas. El color es libre, no de una paleta cerrada.
 */
export interface StageCategory {
  id: string;
  name: string;
  /** hex sin almohadilla, para el selector de color */
  color: string;
  desc?: string;
  addedAt: number;
}

/**
 * Escenario guardado por el usuario. Solo los datos para pintarlo en la biblioteca;
 * el paquete con el proyecto y sus imágenes va aparte en IndexedDB ("stageblob:<id>"),
 * porque resetAll() borra los recursos sueltos al abrir otro escenario.
 */
export interface SavedStage {
  id: string;
  name: string;
  /** descripción corta, como las "mechanics" de las tarjetas de los escenarios oficiales */
  desc?: string;
  /** color propio de la tarjeta (hex sin almohadilla); vacío = hereda el de su categoría */
  color?: string;
  /** palabra que la persona quiera poner en la insignia de la tarjeta; vacía = no hay insignia */
  badge?: string;
  catId?: string;
  /** miniatura JPEG capturada del lienzo en el momento de guardar */
  thumb?: string;
  bytes: number;
  layers: number;
  zoom: number;
  target: TargetVersion;
  directory: string;
  savedAt: number;
}

/** Personaje guardado en la biblioteca del navegador (descargado o importado) */
export interface CharLibEntry {
  id: string;
  name: string;
  source: 'base' | 'user';
  baseId?: string;
  char: CustomChar;
  thumb?: string;
  /** icono de vida del propio mod (images/icons/icon-*.png) recortado */
  iconData?: string;
  /** categoría propia donde el usuario lo guardó (sin definir = "Sin categoría") */
  catId?: string;
  addedAt: number;
}

export interface CharacterSetup {
  x: number;
  y: number;
  camX: number;
  camY: number;
  previewName: string;
  custom: CustomChar | null;
  /**
   * Copia "iluminada" del personaje (Spooky Mansion Erect). P-Slice crea un segundo
   * Character con el nombre sin el sufijo "-dark" (bf-dark -> bf, pico -> pico-playable)
   * y lo funde con el oscuro cada vez que cae un rayo.
   */
  lit: CustomChar | null;
  tint: string;
  alpha: number;
  scrollOverride: boolean;
  scrollX: number;
  scrollY: number;
  focusZoom: number;
  /** efecto .frag aplicado al personaje */
  shader: ShaderFx | null;
  /** comportamiento propio: código Lua de Psych escrito por la persona para este personaje */
  customCode?: string;
  /** shader propio: fragment shader (.frag) escrito por la persona para este personaje */
  customFrag?: string;
}

export interface StageSettings {
  name: string;
  directory: string;
  defaultZoom: number;
  isPixelStage: boolean;
  stageUI: string;
  hideGirlfriend: boolean;
  cameraSpeed: number;
  fixedCamera: boolean;
  fixedCamX: number;
  fixedCamY: number;
  target: TargetVersion;
  modFolder: string;
  imageFolder: string;
  bpm: number;
  autoCamera: boolean;
  /** incluir el evento "Change Stage" (custom_events/) en el ZIP */
  changeStageEvent: boolean;
}

/**
 * Personaje extra del escenario, más allá de BF / GF / DAD: un corista, un invitado…
 * Canta cuando el chart lanza el evento "Cantar extra" (value1 = su nombre, value2 = la
 * animación: singLEFT, singRIGHT, singUP, singDOWN, idle…).
 */
export interface ExtraChar {
  id: string;
  /** etiqueta única: es el tag del sprite en Lua y el value1 del evento */
  name: string;
  x: number;
  y: number;
  scale: number;
  flipX: boolean;
  scrollX: number;
  scrollY: number;
  /** el sprite y sus animaciones, de la biblioteca de personajes */
  custom: CustomChar | null;
}

export interface Project {
  version: 1;
  settings: StageSettings;
  layers: Layer[];
  characters: Record<CharKey, CharacterSetup>;
  extraChars: ExtraChar[];
}

export interface AssetMeta {
  id: string;
  path: string;
  fileName: string;
  width: number;
  height: number;
  hasXml: boolean;
  frameCount: number;
  role: 'stage' | 'character';
  bytes: number;
}

export interface SparrowFrame {
  name: string;
  x: number;
  y: number;
  w: number;
  h: number;
  fx: number;
  fy: number;
  fw: number;
  fh: number;
  rotated: boolean;
}

export interface Diagnostic {
  level: 'error' | 'warn' | 'info';
  msg: string;
  layerId?: string;
}
